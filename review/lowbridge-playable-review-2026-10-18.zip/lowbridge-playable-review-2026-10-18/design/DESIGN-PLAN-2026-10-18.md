# Design plan v2 — cultivation incremental (working title: *Lowbridge*)

18 October 2026, revised the same day after `review/THIRD-PARTY-REVIEW-2026-10-18.md`. This is a design, not a ledger. It takes the accepted content of the interview (setting, classes, masteries, breakthrough count, bank, lifespan, retries) and rebuilds it on Arcanum's machine as corrected in `research/arcanum-mechanics-2026-10-18/MECHANICS-STUDY.md`. Where it reverses an accepted decision it says so in Part F. Every number in Part C exists so that it can be wrong in play.

Reading order: §0 (what changed and how it was checked) → A (the machine) → B (campaign skeleton) → C (first slice, fully specified) → D (data model) → E (validation) → F (supersessions, decisions).

---

## 0. Changes from v1 and how each was verified

| Third-party finding | Verified how | Disposition |
|---|---|---|
| F2 (critical): "skills start at cap 0" misread an absent `max`; Arcanum defaults to 5 | `src/items/skill.js` at pinned commit: `Defaults.max = 5`, `buy = {arcana:20}` | **Accepted.** Study §1 rewritten. Part A now: entry gate → 3–5-level runway with per-level payout → wall. |
| F1 (critical): Part C deadlocks on Lore (`fragment_notes` ← `shu_reading` ← `lore ≥ 2`); `channel_return` unreachable/pointless | Executed Part C v1 as a graph: greedy player stalls at `lore 0`, `field_kit` never reachable | **Accepted.** `fragment_notes` requires only the slip; `channel_return` cut. |
| F3 (high): Sutra Reader has no tags → zero specialist options at B4; breaks ADR 0017 | Tag arithmetic by hand, then by script | **Accepted.** Scholar line removed. Golden Cauldron keeps open entry with the mage line's price shape. |
| F4 (high): B4 "family cap ≥ 5" unreachable for half the histories; Spirit module never unlocked; Mountain Vessel dead for Earth starters | Script over all 11 A→B histories | **Accepted.** Projection is a bridge layer raised by Sword and Formation content; a class unlocks the *next* tier of each line it tags; B4 gates are tier-relative. All 11 histories now have ≥ 2 options incl. ≥ 1 specialist. |
| F5 (high): bank survives retry → spend-then-die loses days; hoard-then-die farms | Rule reading | **Accepted.** Retry refunds bank spent since the checkpoint (reverses ADR 0002's "spent stays spent"). |
| F6 (medium): free Lean-to at Foundation punishes buying it | Reading | **Accepted.** No free home; Lean-to is the prerequisite for Cottage. |
| F7 (medium): 3-of-5 degenerate; 10-min Settling dead wall; `at: 120` unreachable; coin cap 12 absurd | Executed: with "4 of 5" the channel route reached Foundation with **Circulation 0** — the method was skippable (a defect the reviewer did not catch) | **Accepted and extended.** Circulation ≥ 2 is a hard requirement; 3 of 4 supporting pointers; Settling 2 min; curves trimmed; coin cap 20. |
| Q1: missed Arcanum qualities — `require`/`need` split, continuous rate economy, locale stressors, automation growth | `skills.json`: 41 `require`, 19 `need`; `stressors.json`; `extraaction.json` | **Accepted.** Rules 11–13 added; Part C records carry `need`; qi is the one continuous resource; strain gauges for sites from B2; objective queue / hobby slot as rewards. |
| Q2: review mistook deliberate choices (tempo, open village, morality) for omissions | Re-read ADRs 0003/0006/0012 | **Partly accepted.** Locks follow the fiction; tempo is hybrid; Karma is **cut** (not deferred). |
| Q7: 700 records is not cheap for a solo author | Arithmetic | **Accepted.** Build B1–B4 only; Body + Earth + their hybrid first; others after play evidence. |
| Q8: tempo hybrid; keep GC open-entry; TypeScript rewrite not fork | — | **Accepted** as decisions. |
| Owner's final pass: the interwoven skill web was under-researched; audit class/line diversity | Wiki `Skills` page cross-checked against `skills.json`: 1 trunk with 8 threshold gates, 14 source-gated entries, 8 two-parent bridges, 7+ tag-gated masteries that drain their element, 9 cross-feeders, 5+ OR/action entries (`MECHANICS-STUDY.md §1b`) | **Accepted.** B.1 rebuilt as a 20-technique web (trunk, entries, bridges, masteries, helpers); class gates are techniques; roster refined to 4/8/9 with three one-record additions so every line supports "three from one line" and Sword starters get a second B3 route; `b4-gates.py` re-verified (15 histories, all ≥ 2 options, ≥ 1 specialist). |
| Q9: test order — runway loop first, lifespan/bank/objective stops explicitly | — | **Accepted.** Part E reordered. |
| "Apprentice in 3 min" is a tutorial, not a stage | Wiki T0 quest list | **Accepted.** Study §9 corrected; tempo claim is one order of magnitude, not two. |
| First-playable implementation: three owner decisions | Owner confirmed all three handoff defaults on 18 Oct | **Accepted.** Qi is a reservoir; the channel arrangement and `faint_trace` retain separate acquisition routes through B2; all starred roster additions are accepted for later modules. |
| Part B's future per-level bonuses were not specified in Part C | Compared B.1 with C.1 and C.3 before encoding JSON | **Clarified.** C governs this opening: Qi Sense adds +1 qi cap per level; Circulation subtracts 5 seconds per level from Work tasks; Lore levels open the listed gates. B.1's herb/teaching/Lore cross-feeders and Vitality belong to later module implementation, not this slice. |
| Foundation unlocker versus `settling`; ambiguous qi bill | C.3 and baseline Python simulator | **Clarified.** `foundation` is the visible core/supporting gate; `settling` is its 120-second activity. Ten herbs are spent at start; full qi is a threshold, not consumed. Completing Settling grants Foundation and its rewards once. |
| Channel rate and repetition-curve timing | C.3 and baseline `d` counters | **Clarified.** The arrangement adds +50% to `channel_exercise` only. A repetition threshold changes subsequent runs, so the tenth mill run pays the old yield and the eleventh gains +1. |
| Mat can leave full Qi Sense with an unfilled qi reservoir | Real cold-start sequence: buy mat, obtain slip, practise to Qi Sense 3; after 288 practice seconds, Qi Sense is 3/3 but qi is 4/5 | **Fixed.** Breath-gathering remains available while either Qi Sense is below cap or qi is below capacity. At the knowledge wall it restores qi only; capped practice stores no surplus experience. No rate or price changed. |
| C.1 claimed Lore cap 6 at Foundation while C.3 grants +2 | Real JSON routes have cap 3 before Foundation unless Shu's reading was purchased | **Corrected.** Foundation adds +2: Lore cap 5 without Shu, 6 with her reading. The reward is unchanged. |
| Paper timing approximated continuous experience and hollow rewards | Both original Python routes replayed through the actual JSON and 1-second engine | **Measured, not retuned.** Channel 38m50s versus historical 31m20s; hollow 40m20s versus 30m50s. Both pass the 45-minute limit. C.5 remains a comparison target, not a claim of observed timings. |
| Starting then abandoning steady attention could claim its reward from channel practice | Mixed-route event gate inspected against actual earned-level counters | **Clarified.** `faint_trace` requires Circulation ≥ 2 and at least one level earned through steady attention. Merely starting the exercise does not earn its discovery. Visiting both routes stays allowed. |

Simulations: the historical `design/validation/opening-sim.py` approximates the routes at ~31 min. Its `--real-json` extension runs the production TypeScript engine: channel 38m50s, hollow 40m20s, mandatory method, distinct route rewards. `design/validation/b4-gates.py` checks all 15 histories and B4 eligibility. See `playtest/SIMULATION-REPORT.md` for the complete unlock order and differences from the paper model.

---

## Part A — The machine

Thirteen rules. Everything else is content.

1. **A capability is a number with an entry gate, a runway, and a wall.** Resources start capped and small. A technique family is *visible* when its `require` holds, *startable* when its `need` holds (usually an arrangement or a discovery), and once started trains along a **3–5 level runway** where **every level pays a small passive bonus** (a rate, a cap, an unlocked task). The runway ends at a wall that only an outside record moves.
2. **A class raises walls and opens doors.** It adds +1 to its mastery tags (accepted lattice, unchanged), raises its line's entry technique cap by +3, raises its bridge technique if it is a hybrid, unlocks the **next tier** of each line it tags, and is the only thing that lets the line's *mastery* technique exist.
3. **Gated content re-keys itself.** Each line tier has practice, an arrangement and a site that each raise the line's entry technique cap +1. A specialist climbs their own ladder between breakthroughs.
4. **A line is a small web, not one skill.** Each line has an entry technique (source-gated, cheap, runway 5), a mastery technique (entry ≥ 10 **and** the line tag; drains the line's flow resource), and bridges to neighbouring lines that require two parents. Hybrids are techniques first, classes second: a hybrid class requires its bridge at a threshold. Helpers cross-feed: some techniques raise *other* techniques' rate or cap fractionally per level. One content module per line; bridge content lives in both parents' modules.
5. **A breakthrough is a mandatory core + N-of-M supporting pointers + a bill + lifespan.** The core is the thing the stage is about (Foundation: the reconstructed method). The pointers are into systems that already exist. The bill is in the slow shared currencies.
6. **Advancement closes what the fiction removes.** A job is closed when a better one is taken up; a home tier when the player moves; a class choice closes its same-tier rivals. Earlier *places* stay open and gain new uses (ADR 0006/0012). No revision of earlier classes. No hidden quizzes.
7. **One open-entry fallback, shaped like Arcanum's mage line.** Golden Cauldron is enterable from any history, gated on the shared family (`Lore ≥ 8`) and an escalating herb/coin bill; newcomers reach Alchemy 1 (broad: +1 to every open family cap, utility preparations); Pill Refiner → Golden Cauldron reaches Alchemy 2 (the deep recipes). It never raises a line's exclusive family above 5.
8. **Repetition has a curve inside the cap.** Work tasks improve at reachable rep thresholds and some sour late.
9. **Time is the action budget; qi is the one continuous resource.** One primary activity at a time; every task is timed; no stamina/food meter (accepted). Qi is a reservoir: practice `run`s it, breath-gathering, arrangements and homes `rate` it back. The time bank is 1:1 (accepted), starts at **1 hour**, and is a capped resource raised by progression.
10. **Retry refunds the bank.** On a checkpoint retry, bank spent since the checkpoint is refunded up to the current cap; wall-clock accrual since the checkpoint is kept. (Reverses ADR 0002's "spent stays spent".)
11. **See it before you can do it.** `require` shows a record; `need` + `needtext` says what is missing. Every cap hit posts one line naming the raiser if it is visible.
12. **Expeditions have a budget that is not lifespan.** From B2, sites carry strain gauges (Arcanum's stressors): a site run drains one or two gauges; rest and techniques restore them; an emptied gauge ends the outing with its discoveries kept. Cloudwell's three stages are strain events.
13. **Scheduling agency grows.** B2 grants an objective queue (next task starts when the current objective stops); B3 grants one hobby slot (a zero-attention filler that runs while paused); later tiers raise the bank and add a second slot.

Tempo: **hybrid.** Opening through Foundation at active incremental tempo (20–180 s tasks, Foundation in ~30 min); B2–B4 durations ramp into hours as the bank cap grows 1 h → 6 h → 24 h → 72 h. The 3–5-day Cloudwell target stays as a hypothesis.

---

## Part B — Campaign skeleton

### B.1 The technique web (B1–B4)

Shapes taken from Arcanum's skill graph (`MECHANICS-STUDY.md §1b`): a trunk with a threshold clock, source-gated entries, two-parent bridges, class-gated masteries that drain the line's resource, cross-feeding helpers, OR/action entries. Twenty techniques through B4.

**Trunk and shared**

| Technique | Entry | Per level | Gates (threshold clock) |
|---|---|---|---|
| **Lore** | Cracked Jade Slip | +1 herbs cap; +5% teaching-record speed | 2 Shu's reading · 3 every line entry · 5 every bridge · 8 Golden Cauldron, second-tier teachings · 10 every mastery |
| **Qi Sense** | Cracked Jade Slip | +1 qi cap; +5% Lore rate | sites at 1/2/3; bridges needing perception |
| **Settling** | action: 2 sites completed | +1 strain cap (all gauges) | expeditions from B2 |
| **Composure** | Settling ≥ 4 | strain rate −5% | Cloudwell pause |

**Lines** — each has a flow resource (generated by its entry per level, drained by its mastery and its recipes) and a gathered material.

| Line | Entry technique (need: source + Lore 3) | Flow / material | Mastery (entry ≥ 10 + tag; runs flow) | Bridges (two parents, Lore 5) |
|---|---|---|---|---|
| **Body** | **Circulation** — source: channel stones *or* steady-attention (opening); per level: work −5 s, Vitality max +1, rate +0.01 | Vitality / Marrow herbs | **Tempering** — carry +1, hazard strain resist | **Rooting** = Circulation 5 + Ground Reading 3 (stationary ground connection; feeds Circulation rate +0.05/lv) · **Quenching** = Blade Intent 5 + Circulation 3 (reinforced edge; feeds Blade Intent rate) · **Tonics** = Refining 3 + Circulation 3 (conditioning doses; feeds Circulation rate) |
| **Sword** | **Blade Intent** — source: practice post; per level: contact yield +10%, Edge max +1 | Edge / whetstone grit | **Severing** — opens sealed things; cut range | **Projection** = (Blade Intent 5 **or** Array Craft 5) + Qi Sense 4; alt-entry: sit Fernhollow ×10 (will beyond the body; range +1/lv; Will max +1; feeds Qi Sense rate) · Quenching (above) |
| **Earth** | **Ground Reading** — source: survey stakes; per level: surveys reveal +1 feature, Ground-qi max +1 | Ground-qi / veined ore | **Vein Sense** — deposits, stable lines through disturbance | Rooting (above) · **Anchoring** = Ground Reading 5 + Array Craft 3 (terrain-bound arrangements; feeds Array Craft cap +0.1/lv) |
| **Formation** | **Array Craft** — source: drawing board + inked tokens; per level: arrangement efficiency +1, Pattern max +1 | Pattern / inked tokens | **Fixing** — durable arrangements, site modifiers | Anchoring (above) · Projection (above) · **Warding** = Projection 5 + Array Craft 5 (triggered responses; event hooks) |
| **Alchemy** | **Refining** — source: vessel + herb rack; per level: recipe tier access, Essence max +1 | Essence / pill residue | **Transmutation** — demanding transformations (Golden Cauldron's payoff) | Tonics (above) · **Extraction** = Refining 3 + Qi Sense 3 (preserve fleeting properties; feeds Refining rate) |

Spirit has no entry of its own in B1–B4: it *is* Projection and Warding, and the Spirit tag comes from Sword/Formation/Spirit classes (accepted). A Spirit-first entry (a "Communion" technique with its own source) is the natural B5 addition if play shows demand.

Mastery tags remain exactly as ADR 0015 defines them. Techniques are what tags *do*; bridges are where history-dependent opportunity lives.

### B.2 Breakthrough ladder

| # | Name | Core (mandatory) | Supporting: N of M | Bill | Closes | Lifespan | Class |
|---|---|---|---|---|---|---|---|
| 1 | **Foundation** | Circulation ≥ 2 | 3 of 4 (Part C) | 10 herbs, full qi, Settling 2 min | mill work once ferry hauling is taken up | +5 y | none; unlocks Circulation runway to 5, Cottage, Old Ridge lead, four B2 teaching records |
| 2 | **First Direction** | intended line's entry technique ≥ 3 and its introduction used | 3 of 4: {Lore ≥ 4, any tier-2 arrangement, Old Ridge first observation, 200 coin lifetime} | 20 herbs, 10 line material, 60 coin | the other three starters; village job once ridge work is taken | +8 y | Body Disciple / Sword Disciple / Earth Listener / Formation Student |
| 3 | **Second Direction** | intended class's technique gate (B.3): entry ≥ 8 for depth, bridge ≥ 3 for hybrids | 3 of 5 (ADR 0016's five, as pointers: reliable method = entry at cap; returning-chime site cleared; study arrangement installed; survey spur reopened; a paid commission) | 40 herbs, 20 line material, 150 coin | same-tier rivals | +10 y | Iron Marrow / Mountain Vessel / Blade Body / Spirit Blade / Earth Array / Deep Listener / Array Keeper / Pill Refiner |
| 4 | **Cloudwell** | ADR 0018's three conditions + intended class's technique gate (mastery ≥ 3 for depth, bridge ≥ 5 for hybrids) | — | per approach (ADR 0018) | same-tier rivals; waystation job once basin work is taken | +15 y | Jade Body / Sword Heart / Vein Adept / Grand Array / Mountain Heart / Stone Ward / Spirit Warden / Spirit Alchemist / Golden Cauldron |
| 5–8 | as CAMPAIGN-OUTLINE's roles | — | 3 of 5 | — | — | +20/+30/+50/— | one per line per tier; B6 requires a permanent-transformation record |

**Built in this plan: B1–B4 only.** 5–8 are shape, not content.

### B.3 Classes as keys (B2–B4) — verified by `b4-gates.py`

Gates are **techniques**, not bare cap numbers (as Arcanum: Necromancer needs `reanimation ≥ 7`). Roster 4 / 8 / 9 — Arcanum's core tiers run 5 / 6 / 9 / 7. Three additions over ADR 0016/0017 (marked ★), each one key record into a module that already exists: they restore "three from one line" for Earth and Formation and give Sword starters a second B3 route.

| Class | Tags | Gate | Raises | Unlocks |
|---|---|---|---|---|
| Body Disciple | Body | Circulation ≥ 3, its introduction used | Circulation +3 | Body tier 1 |
| Sword Disciple | Sword, Spirit | Blade Intent ≥ 3 | Blade Intent +3, Projection +1 | Sword tier 1 |
| Earth Listener | Earth | Ground Reading ≥ 3 | Ground Reading +3 | Earth tier 1 |
| Formation Student | Formation, Spirit | Array Craft ≥ 3 | Array Craft +3, Projection +1 | Formation tier 1 |
| Iron Marrow Adept | Body | Body ≥ 1, Circulation ≥ 8 | Circulation +3 | Body tier 2 |
| Mountain Vessel | Body, Earth | Body or Earth ≥ 1, Rooting ≥ 3 | Rooting +3, both entries +3 | Body next, Earth next |
| ★ Blade Body | Sword, Body | Sword or Body ≥ 1, Quenching ≥ 3 | Quenching +3, both entries +3 | Sword next, Body next |
| Spirit Blade | Sword, Spirit | Sword or Spirit ≥ 1, Projection ≥ 3, Blade Intent ≥ 5 | Projection +3, Blade Intent +3 | Sword tier 2 |
| Earth Array Adept | Earth, Formation | Earth or Formation ≥ 1, Anchoring ≥ 3 | Anchoring +3, both entries +3 | Earth next, Formation next |
| ★ Deep Listener | Earth | Earth ≥ 1, Ground Reading ≥ 8 | Ground Reading +3 | Earth tier 2 |
| ★ Array Keeper | Formation | Formation ≥ 1, Array Craft ≥ 8 | Array Craft +3 | Formation tier 2 |
| Pill Refiner | Alchemy, Body | Refining ≥ 5 (open) | Refining +3, Tonics +3 | Alchemy tier 1 |
| Jade Body | Body | Body ≥ 2, Tempering ≥ 3 | Tempering +2, Circulation +3 | Body tier 3 |
| Sword Heart | Sword, Spirit | Sword ≥ 2, Severing ≥ 3 | Severing +2, Blade Intent +3 | Sword tier 3 |
| ★ Vein Adept | Earth | Earth ≥ 2, Vein Sense ≥ 3 | Vein Sense +2, Ground Reading +3 | Earth tier 3 |
| ★ Grand Array Adept | Formation | Formation ≥ 2, Fixing ≥ 3 | Fixing +2, Array Craft +3 | Formation tier 3 |
| Mountain Heart | Body, Earth | Body ≥ 1 & Earth ≥ 1, Rooting ≥ 5 | Rooting +3, both entries +2 | Body next, Earth next |
| Stone Ward | Earth, Formation | Earth ≥ 1 & Formation ≥ 1, Anchoring ≥ 5 | Anchoring +3, Fixing exists at Formation ≥ 1 | Formation next, Earth next |
| Spirit Warden | Spirit, Formation | Spirit ≥ 2, Warding ≥ 3 | Warding +3, Projection +2 | Formation next |
| Spirit Alchemist | Spirit, Alchemy | Spirit ≥ 1 & Alchemy ≥ 1, Extraction ≥ 5, Projection ≥ 3 | Extraction +3, Projection +2 | Alchemy next |
| Golden Cauldron | Alchemy | Lore ≥ 8, Refining ≥ 5 (open); bill 80 herbs + 400 coin (newcomer) / 40 + 200 (Pill Refiner) | Refining +3; +1 to every open entry | Alchemy next; Transmutation exists |

Result (`b4-gates.py`): **15 A→B histories** (Body 4, Sword 3, Earth 4, Formation 4), every one with ≥ 2 B4 options and ≥ 1 specialist; every line supports a pure three-class chain. Golden Cauldron is reachable from all 15; the rarest specialist (Sword Heart, Spirit Warden, Stone Ward, Grand Array, Spirit Alchemist) from 2 each.

**Diversity audit.** Mechanically the five lines differ by *what their resource buys*: Body spends Vitality on access (places you can carry into, strain resistance); Sword spends Edge on openings (sealed things, cuts at range once Projection is in); Earth spends Ground-qi on information (routes, deposits, stable lines); Formation spends Pattern on persistent modifiers (home and site arrangements, triggered wards); Alchemy spends Essence on consumables that change other tasks' costs. Hybrids are a third verb, not a sum: Rooting (stationary connection), Quenching (reinforced edge), Anchoring (terrain-bound arrangement), Warding (event hook), Extraction (preservation), Tonics (conditioning). Thin spots, deliberately deferred: no Spirit-first entry before B5; no water/fire/wood elements (Earth is the chosen element, per the original design); no beast/companion line (summons excluded by the class map).

**Distinctness is in the module, not the number.** Each line's module uses different *verbs*, not a shared template: Body = load, hazard and endurance tasks whose payoff is access (places you can carry into); Sword = contact precision tasks whose payoff is yield and opening sealed things; Earth = survey sites whose payoff is routes and deposits; Formation = arrangements whose payoff is home and site modification; Alchemy = recipes whose payoff is consumables that change other tasks' costs. Stone Ward makes a durable boundary at a site (a persistent site modifier); Spirit Warden makes a triggered response (an event hook). Those are record *kinds*, not +3s.

### B.4 Line modules — tier template, instantiated per line with that line's verbs

Per tier: 3 practice tasks for the entry technique (the top one raises its cap +1 once), 1 arrangement that raises the cap +1 and 1 that raises rate (the *source* for the next tier's technique), the line's flow resource (max raised by the arrangement) and material, 2 recipes or equivalents that spend the flow, 2 sites (first clear +1 cap; repeat yields material; strain gauges), 1 teaching record (Lore ≥ k), and **the bridge content shared with a neighbour** (one practice task and one site per bridge, listed in both modules). ≈ 14 records per tier.

Build order: **Body tier 1–3, Earth tier 1–3, the Rooting bridge and its classes (Mountain Vessel / Mountain Heart)**, then Formation (+ Anchoring, Warding), Sword (+ Projection, Quenching), Alchemy (+ Tonics, Extraction). Two lines and one bridge fully authored is the smallest version of Part B that tests Part A on a real lattice: a pure chain, a hybrid chain, and the fallback.

### B.5 Home

| Tier | Name | Space | Rate | Unlock | Closes |
|---|---|---|---|---|---|
| 0 | Hayloft | 2 | — | start | — |
| 1 | Lean-to | 4 | — | 40 coin + 6 timber | Hayloft (on move) |
| 2 | Cottage | 8 | qi +0.1/min | Foundation + Lean-to + 300 coin | Lean-to (on move) |
| 3 | Ridge Room | 10 | Ground Reading rate +10%, Lore rate −10% | B2 | — (relocation; village home retained) |
| 4 | Basin Lodging | 12 | coin −1/min rent | B3 | — |
| line homes | Mountain Hermitage, Blade Hall, Array Court, Still-room | 20–40 | line caps/rates | line tier 3 class | — |

Arrangements consume space; relocation carries what fits; place-bound arrangements are re-established (ADR 0006).

### B.6 Lifespan and bank

- Age 18, lifespan 80 (accepted). **1 activity hour = 0.25 fictional years.** Activity budget by stage (targets, not deadlines): B1 ≈ 1 h, B2 ≈ 10 h, B3 ≈ 25 h, B4 ≈ 40 h → ≈ 76 h → ≈ 19 fictional years to Cloudwell (inside Q117's 10–20). Pauses and bank accrual do not age.
- Bank cap: 1 h → 6 h (B1) → 24 h (B2) → 72 h (B3); a Formation tier-2 arrangement adds +24 h.
- Retry: ADR 0002 restore rules, with rule A.10's bank refund.

---

## Part C — First playable slice, fully specified

Bound: cold start → Foundation. No classes, no waystation. The design target was ~30 min active; the implemented one-second simulation measures channel 38m50s and hollow 40m20s. These remain below the 45-minute validation bound. The 2–3-visit idle pattern still needs human play evidence.

### C.1 Stat sheet

| Quantity | Entry | Runway / cap | Per-level payout | Raised by | Gates |
|---|---|---|---|---|---|
| Coin | start | 20 | — | Pouch → 50; Strongbox → 100 | purchases |
| Herbs | start | 12 | — | Herb Rack → 24 | Foundation bill |
| Timber | field kit | 6 | — | — | Lean-to, racks |
| Stone | channel | 8 | — | — | channel arrangement |
| Qi | slip | 2 + Qi Sense level | — | Foundation → +10 | Foundation bill; practice `run` after B1 |
| Lore | slip (`require`), nothing to `need` | 0→3 | lv1: field kit, herb rack visible; lv2: Granny Shu's reading; lv3: pointer | Shu's reading → 4; Foundation adds +2 (5 without Shu, 6 with) | teaching records |
| Qi Sense | slip | 0→3 | lv1: gather herbs, channel observation; lv2: hollow observation; each lv +1 qi cap | channel discovery +1; hollow sitting +2; Foundation +2 | sites |
| Circulation | `require`: slip; `need`: channel arrangement **or** steady-attention | 0→3 | each lv: work tasks −5 s | Foundation → 5 | **Foundation core** |
| Home space | — | 2 (Hayloft) | — | Lean-to 4 | arrangements |
| Bank | start | 1 h | — | Foundation 6 h | acceleration |
| Age | 18 | 80 | — | Foundation +5 | — |

Practice runway: level *n* needs 60·*n* seconds of continuous practice at base rate; arrangements raise rate. Part C defines the opening's per-level modifiers: Qi Sense adds +1 qi capacity and Circulation shortens every Work-group task by 5 seconds per level (minimum 1 second). Lore levels open the listed gates. The additional B.1 cross-feeders and line resources are reserved for later modules.

### C.2 Places and people

- **Lowbridge**: a village where the mill stream meets the ferry road; the wilds beyond the ridge. Home: the hayloft above Miller Wen's barn.
- **Miller Wen** — Mill Work; later the ferry hauling and commissions.
- **Granny Shu** — herb-wife and peddler. Her stall offers herb-sorting from minute 0; on the third sort she mentions the cracked slip "nobody wants" (6 coin). At Lore 2 she reads its hard characters (raises Lore cap to 4).
- **Headman Lu** — posts the Mill Channel bounty.
- **Mill Channel** — the damaged stream channel: awkward terrain, clear qi.
- **Fernhollow** — the sheltered hollow: accessible, faint qi.

### C.3 Records (`require` = visible, `need` = startable with `needtext`)

**Work**

| id | require | need | length | result | at |
|---|---|---|---|---|---|
| mill_work "Haul sacks at the mill" | — | — | 30 s | coin +3 | 10: +1; 30: +1 |
| sort_herbs "Sort herbs at Granny Shu's" | — | — | 20 s | herbs +1 | 3: log — the slip |
| gather_herbs | Qi Sense ≥ 1 | — | 45 s | herbs +2 | 10: +1 |
| cut_timber | field_kit | — | 60 s | timber +2 | — |
| ferry_hauling | foundation | — | 40 s | coin +6; first run closes mill_work ("Wen hires a boy") | 20: +2 |

**Purchases**

| id | require | need (needtext) | cost | mod |
|---|---|---|---|---|
| coin_pouch | coin ≥ 20 (shown on cap hit) | coin ≥ 15 | 15 | coin cap +30 |
| jade_slip "Cracked Jade Slip" | sort_herbs reps ≥ 3 | coin ≥ 6 ("six coin") | 6 | opens Lore 0/3, Qi Sense 0/3, qi 0/2; unlocks breath_gathering, fragment_notes |
| field_kit "Cord, stakes, hook" | Lore ≥ 1 | coin ≥ 20 | 20 | unlocks cut_timber, clear_channel |
| shu_reading "Granny Shu reads the hard characters" | Lore ≥ 2 | herbs ≥ 5 ("she wants five good bundles") | 5 herbs | Lore cap +1 |

**Practice** (continuous; stop at chosen objective)

| id | require | need (needtext) | run / effect | cap |
|---|---|---|---|---|
| breath_gathering "Practise the slip's breath method" | jade_slip | Qi Sense < cap **or** qi below capacity ("the slip says nothing more; the next character is missing; the qi reservoir is full") | Qi Sense exp 1/s below its cap; qi +1 per 30 s, including at the knowledge wall | — |
| fragment_notes "Copy and study the slip" | jade_slip | Lore < cap | Lore exp 1/s | — |
| channel_exercise "Circulate at the channel stones" | channel_arrangement | Circulation < cap | Circulation exp 1/s (+50% at home) | — |
| steady_attention "Steady-attention exercise" | fernhollow sits ≥ 3 | Qi Sense ≥ 3 | first start opens Circulation 0/3; Circulation exp 1/s; grants `faint_trace` at lv 2 | — |
| settling "Settle the foundation" | foundation unlocker | — | 2 min; the breakthrough act | — |

**Sites**

| id | require | need (needtext) | length | result |
|---|---|---|---|---|
| channel_observe "Walk the broken channel" | Qi Sense ≥ 1 | — | 2 min | stone +2; first: Qi Sense cap +1; discovery *flow pattern*; unlocks clear_channel |
| clear_channel "Clear the fall and reset the stones" | channel_observe | field_kit ("you need cord and a hook") | 5 min | coin +10 (bounty); stone +4; discovery *the stones hum where the flow bends*; unlocks channel_arrangement |
| fernhollow_observe "Sit quietly in Fernhollow" | Qi Sense ≥ 2 | — | 2 min | discovery *a faint current, easy to lose*; unlocks sit_fernhollow |
| sit_fernhollow "Sit the hollow at dusk" | fernhollow_observe | Qi Sense < cap or sits < 3 | 3 min | Qi Sense exp +60; first: Qi Sense cap +2; at 3: unlocks steady_attention |

**Home arrangements** (Hayloft space 2)

| id | require | need | cost | space | mod |
|---|---|---|---|---|---|
| practice_mat | — | coin ≥ 8, space | 8 | 1 | breath_gathering rate +25% |
| herb_rack | Lore ≥ 1 | coin 10, timber 2, space | 10 + 2 timber | 1 | herbs cap +12 |
| channel_arrangement "Channel stones set in the floor" | clear_channel | stone ≥ 4, space ≥ 2 ("four stones; two spans of floor") | 4 stone | 2 | opens Circulation 0/3; Circulation rate at home +50%; unlocks channel_exercise |
| lean_to (home tier 1) | — | coin 40, timber 6 | 40 + 6 timber | space 4 | closes Hayloft on move |
| strongbox | lean_to | coin 25, timber 2, space | 25 + 2 timber | 1 | coin cap +50 |

**Foundation (breakthrough 1)**

Unlocker "Lay the foundation" is visible once Circulation is open. **Core:** Circulation ≥ 2. **Supporting, 3 of 4:** Qi Sense ≥ 3 · Lore ≥ 2 · home space used ≥ 2 · clear_channel **or** steady_attention completed. **Bill:** 10 herbs spent at the start of `settling`; qi must be full and is not consumed. The unlocker is a gate, not a second purchase. `settling` lasts 2 min. On completion: lifespan +5; Circulation cap → 5; Lore cap +2; Qi Sense cap +2; qi cap +10; bank cap 6 h; unlocks ferry_hauling, Cottage (needs Lean-to), ridge_trail_observe, the four B2 teaching records (Lore ≥ 3), "a traveller asks after the one who cleared the channel". Decision pause. In this first slice the Cottage, ridge and teaching records are informational leads; their activities belong to the next slice.

Measured with actual JSON: channel-only route 38m50s (13 mill runs, pouch, kit, arrangement, supporting 4/4); hollow-only route 40m20s (2 mill runs, no home spend, supporting 3/4). Neither can skip the method. The preserved historical Python approximation remains 31.3/30.8 min for comparison.

### C.4 The slip

> *Lesser Breath-Gathering Method* — leaves 1, 2, 8 of twelve. "Sit as water sits. Draw the breath past the throat and let it pool below the navel. Feel for what is not air." Leaf 8: "…when the pooled breath turns, do not follow it. Wait at the turning. The rest is…" The remaining characters are chipped away.

Leaf 8's missing sentence is what the channel's humming stones and Fernhollow's steady attention each supply, differently.

### C.5 Session script

| min | event |
|---|---|
| 0 | Hayloft. Two tasks: Haul sacks (coin), Sort herbs (herbs). Coin 0/20. |
| 1 | Third sort: Granny Shu mentions the slip. Slip visible, needs 6 coin. |
| 4 | Slip. Lore 0/3, Qi Sense 0/3, qi 0/2 appear; Breath-gathering and Copy-the-slip appear. |
| 6 | Qi Sense 1: gather herbs and the channel walk appear. Coin hits 20/20 at some point here: Pouch appears. |
| 10 | Qi Sense 2: the hollow appears. Lore 1: field kit and herb rack visible. Qi Sense 3/3 — **wall**: "the next character is missing." Two leads. |
| 14–27 | Channel: walk (cap → 4), work for the kit, clear the fall (bounty), set the stones (Circulation opens 0/3), circulate. Hollow: sit three dusks (cap → 5), steady attention (Circulation opens 0/3). |
| 27–29 | "Lay the foundation" shows core + 3-of-4; fill the gap (herbs, the other site's first look, a second arrangement). |
| 29–31 | Settling (2 min). Foundation. Three new leads. Decision pause. |

### C.6 Interface

Left: resources `x/cap` with bars; families `level/cap` with the runway shown as pips and "what raises this" on hover. Centre: Work / Practice / Sites / Home groups; buttons show `needtext` greyed when visible-but-not-startable. Right: log — discoveries, cap hits with raiser names, prose. Top: bank `x/cap` with an Accelerate toggle naming the current objective.

---

## Part D — Data model

Record grammar (Arcanum's, reproduced in TypeScript; not a fork):

```
record := { id, name?, desc?, group?, tags?,
            require?: expr, need?: expr, needtext?,
            buy?: {res: n}, cost?: {res: n},
            length?: seconds | continuous,
            run?: {res: n/s}, effect?: {res: n/s}, result?: {res: n},
            mod?: {"<x>.max": n, "<x>.rate": n, ...},
            at?: {rep: {path: n}}, every?: {n: {path: n}},
            disable?: [ids], max?: n, space?: n, strain?: {gauge: n} }
family := record + { runway: n, perLevel: mod }
expr  := boolean over g.<id> (level/count), g.<id>.max, tags, classes, reps
```

Kinds: resource, family, task, site, arrangement, home, class, breakthrough (core + pointers + bill), teaching, recipe, technique. One JSON per line module plus shared modules. Saves: level/cap/reps per id, class history, age, bank, checkpoint snapshot.

Engine: TypeScript, ~1 kLOC: one expression evaluator shared by the browser runtime and the Part E validator; 1 s tick; one active task; objective stops; bank accrual on wall-clock; acceleration = run ticks from bank until objective or pause; strain gauges; checkpoint snapshot with bank refund. IndexedDB with export. Vue or plain DOM is a presentation choice, not a design one.

---

## Part E — Validation

Run on every content change, before any human plays:

1. **Reachability**: walk every `require`/`need` from cold start; every record reachable; every family's entry and every cap raiser reachable before anything that needs it. (Seeded by `opening-sim.py`.)
2. **No self-key**: no class is required by a record it unlocks.
3. **History coverage**: all A→B→C histories; ≥ 2 B4 options with ≥ 1 specialist; every line's pure chain reachable; every bridge's two parents reachable before the bridge. (`b4-gates.py`: 15 histories pass.)
4. **Pacing from data**: time-to-Foundation at empty bank ≤ 45 min active; no pre-B4 task > 2 h ordinary; B1–B4 activity budget within 60–90 h; fictional age at Cloudwell within 28–38.
5. **Mandatory-core check**: no breakthrough reachable with its core family at 0 (the defect the simulator found).

Playtest questions, ranked:

1. Does training along a 3-level runway with per-level payouts, then hitting the wall, then moving it by a discovery, feel like *cultivation* — or like a quest flag with a number?
2. Channel vs hollow: a felt difference in how Foundation is reached (infrastructure vs perception), or click-everything?
3. Objective stops with an empty bank across a simulated return visit: clean?
4. Foundation's bill, lock (mill work closing when ferry hauling is taken) and new leads: a threshold, or a loss?
5. Is `needtext` enough to keep a stuck player from leaving?

---

## Part F — Supersessions and decisions

**Reversed or changed from accepted records**

| Record | Change | Why |
|---|---|---|
| ADR 0013 ¶2 | Clarified, not reversed: families have levels and caps; no global knowledge currency | The original refusal targeted a generic XP currency; levels/caps are what Arcanum actually does |
| ADR 0002 "spent banked time stays spent" | Retry refunds bank spent since the checkpoint | Removes the spend-then-die penalty and the hoard-then-die farm |
| No lock rule | Jobs close when a better one is taken; homes close on move; class choice closes same-tier rivals; no revision | Arcanum locks at every tier; follows the fiction rather than a stage's toolset |
| Q114/Q123 foundation "within the first day" | Within the first session (~30 min active); later stages ramp | Hybrid tempo |
| Bank cap "a few days" | 1 h at start, raised by progression | Arcanum `offlinetime.max 3600`; the cap is a reward |
| Five B3 milestones as authored projects | Same five, as pointers into existing records | Arcanum's tier quests are pointers |
| ADR 0003 "no energy meter" | Kept for stamina/food; qi is a continuous reservoir with run/rate | The rate economy is where homes and arrangements become felt |
| ADR 0016 roster (5 at B3) | 8: adds Blade Body (Sword–Body bridge), Deep Listener (pure Earth), Array Keeper (pure Formation) | Every line must support "three from one line" (Arcanum's stated optimal play); Sword starters had one B3 route |
| ADR 0017 roster (7 at B4) | 9: adds Vein Adept (pure Earth), Grand Array Adept (pure Formation) | Same; each is one key record into a module that exists anyway |
| ADR 0015 "mastery totals are qualifications, not trainable levels" | Kept for tags; techniques are the trainable layer beneath them, and class gates name a technique | Arcanum gates classes on skills (Necromancer: `reanimation ≥ 7`), not on tag counts alone |

**Unchanged**: eight breakthroughs; four starters; all original B3/B4 classes and their tags (incl. Golden Cauldron open entry per Q72); mastery counting; one activity at a time; 1:1 bank; age 18/80; checkpoint restore; Cloudwell structure (ADR 0018); noncombat viability; optional sects; desktop text-panel presentation; no morality axis (now recorded as a decision).

**Decisions taken in this revision (from the third-party recommendations)**: hybrid tempo; Golden Cauldron as the fallback, no scholar line; TypeScript engine implementing the grammar, Arcanum as reference not fork; Karma cut; B1–B4 only; Body + Earth + hybrid first.

**Owner decisions, confirmed 18 October 2026**: qi-as-reservoir is accepted under ADR 0003; `faint_trace` and the channel arrangement retain their distinct acquisition routes through B2 (no automatic convergence); the starred roster additions are accepted for later modules. Neither route blocks visiting the other place. Human playtest evidence, rather than further design questions, determines the next revision of this opening.
