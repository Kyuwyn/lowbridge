# First playable implementation — 18 October 2026

Scope: cold start in Lowbridge through Foundation and its decision pause. Plain DOM, TypeScript, JSON content, Bun build/serve/test. No runtime framework, combat, classes, waystation, or later line modules. The frozen review package remains untouched.

The owner confirmed all three v2 defaults: qi is a reservoir; route rewards retain their separate sources through B2; the starred class additions are accepted for later content.

## Files and ownership

- `src/data/shared.json`, `src/data/opening.json`, `src/content.ts`: resources, families, and every Part C record in the Part D grammar. Explicit `kind`, initial stats, narrative events and breakthrough pointers supply the metadata the table implies. All numerical corrections also go into the design plan's §0.
- `src/types.ts`, `src/expression.ts`, `src/engine.ts`: typed records/state, a restricted expression parser shared by runtime and validators, one active task, 1-second activity ticks, level costs `60 × next level`, per-level modifiers, task curves, space, visibility, objective stops and meaningful discovery pauses.
- `scripts/validate.ts`, `scripts/routes.ts`, `tests/`: exercise the real JSON and engine, both route preferences, record coverage, no-self-key, mandatory core, pacing, time accounting and recovery. Retain and extend the two Python validators.
- `src/main.ts`, `src/ui.ts`, `src/style.css`, `index.html`: top bank and named objective; left capped resources and family runway; centre Work/Practice/Sites/Home plus purchases and breakthrough; right discoveries/cap log. Native keyboard controls, visible missing requirements, responsive panels.
- `src/persistence.ts`: versioned JSON save validation, atomic IndexedDB transactions, export/import, elapsed-time settlement on return. Save authoritative data only. Refuse malformed imports without changing the running game.
- `scripts/build.ts`, `scripts/serve.ts`, `package.json`, `tsconfig.json`: small local build and preview. Browser smoke may use a separate test entry point; test controls stay outside the production player interface.
- `playtest/`: one-page feedback sheet, measured route report and importable saves.

## Engine contract

Use `GameEngine(records, state?)` and export shared types. The core public surface is `state`, `record(id)`, `stat(id)`, `visible(id)`, `availability(id)`, `start(id, objective?)`, `stop()`, `advance(seconds)`, `accelerate()`, and `retry()`. `availability` returns `{ok, reason}`. Objectives are absolute repetition, family-level or resource targets, with a sensible single-completion/next-level default. The UI and route runner call this same surface; they never implement rewards.

State includes stats (value, max, exp, rate, reps), one active task with progress and objective, age/lifespan, activity seconds, bank seconds/cap/spent-since-checkpoint, log, visible-history, disabled ids and an exact checkpoint. New visibility is remembered, so a visible gate does not disappear when a resource is spent.

Elapsed time advances the saved activity only to its objective or next meaningful discovery; the unused remainder becomes bank, never both. Bank seconds accelerate only the chosen current objective and age normally. An exhausted bank leaves unfinished work at ordinary speed. Each next objective needs acceleration re-enabled. Retry restores checkpoint character/world state and refunds bank spent since it, retaining later accrual up to the restored cap without repeated-refund farming. Foundation creates a new checkpoint and pauses.

## Integration and evidence

1. Keep the current Python validators green; encode all Part C records and document ambiguities before tuning.
2. Run both opening routes with real one-second ticks and no starting bank; collect exact unlock order, activity time, caps and unknown-raiser lines. Reachability includes optional purchases/home records, not only the successful routes.
3. Test objective/decision boundaries, bank depletion and return visits, capped income, practice curves, spending/space, save rejection/roundtrip, retry refund and lifespan stops.
4. Build the browser app; smoke both routes through browser-loaded code, validate persistent reload and export/import, keyboard focus and narrow/desktop layout. Separate accelerated test execution time from ordinary simulated activity time.
5. Deliver a running local preview, fresh and route save exports, the ranked five-question sheet, and a report comparing the observed session with C.5. Report every design correction and every remaining limit.
