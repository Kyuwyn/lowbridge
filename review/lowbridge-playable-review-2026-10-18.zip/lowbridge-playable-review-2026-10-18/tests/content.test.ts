import { describe, expect, test } from "bun:test";
import { records } from "../src/content";
import { GameEngine } from "../src/engine";
import { validateContent, validateGrammar, validateMandatoryCores } from "../scripts/validate";
import { runRoute } from "../scripts/routes";
import type { GameRecord } from "../src/types";

function changed(id: string, change: (record: GameRecord) => void): GameRecord[] {
  const copy = structuredClone(records);
  change(copy.find(record => record.id === id)!);
  return copy;
}

describe("Part E validation over real opening content", () => {
  test("both Python preferences reach Foundation within 45 minutes and branches witness every record", () => {
    const report = validateContent();
    expect(report.errors).toEqual([]);
    expect(report.ok).toBe(true);
    expect(report.missing).toEqual([]);
    expect(report.reachedCount).toBe(report.recordCount);
    // Furniture competes for the same floor: the witnesses genuinely use separate histories.
    const furnished = report.coverageBranches.find(route => route.name === "furnished-hollow")!;
    const stones = report.coverageBranches.find(route => route.name === "stones-and-storage")!;
    expect(furnished.completed).toContain("practice_mat");
    expect(furnished.completed).not.toContain("channel_arrangement");
    expect(stones.completed).toContain("channel_arrangement");
    expect(stones.completed).not.toContain("practice_mat");
    expect(furnished.state.disabledIds).toContain("hayloft");
    expect(stones.state.disabledIds).toContain("mill_work");
  });

  test("an optional purchase gated behind itself fails the no-self-key rule", () => {
    const errors = validateGrammar(changed("strongbox", record => { record.require = "g.strongbox > 0"; }));
    expect(errors.some(error => error.includes("strongbox") && error.includes("self-key"))).toBe(true);
  });

  test("a mat can reach the Qi Sense wall between qi pulses, and breath can fill the last qi without XP overflow", () => {
    const prelude = ["mill_work", "mill_work", "mill_work", "practice_mat", "sort_herbs", "sort_herbs", "sort_herbs", "mill_work", "mill_work", "jade_slip", "breath_gathering", "breath_gathering", "breath_gathering"];
    const route = runRoute("hollow-only", { prelude, maxActions: prelude.length });
    const engine = new GameEngine(records, route.state);
    expect(engine.stat("qi_sense").value).toBe(engine.stat("qi_sense").max);
    expect(engine.stat("qi").value).toBeLessThan(engine.stat("qi").max);
    expect(engine.availability("breath_gathering").ok).toBe(true);
    engine.start("breath_gathering", { kind: "resource", id: "qi", target: engine.stat("qi").max });
    while (engine.state.active) engine.advance(1);
    expect(engine.stat("qi").value).toBe(engine.stat("qi").max);
    expect(engine.stat("qi_sense").exp).toBe(0);
    expect(engine.stat("qi_sense").value).toBe(engine.stat("qi_sense").max);
  });

  test("a mixed route earns faint trace through actual steady attention, not merely starting it after channel training", () => {
    const channel = runRoute("channel-only");
    const beforeSettling = channel.actions.findIndex(action => action.id === "settling");
    const route = runRoute("channel-only", { maxActions: beforeSettling });
    const engine = new GameEngine(records, route.state);
    expect(engine.stat("foundation").value).toBe(0);
    expect(engine.stat("circulation").value).toBe(2);
    for (let dusk = 0; dusk < 3; dusk++) {
      expect(engine.start("sit_fernhollow").ok).toBe(true);
      while (engine.state.active) engine.advance(1);
    }
    expect(engine.start("steady_attention").ok).toBe(true);
    engine.stop();
    expect(engine.stat("faint_trace").value).toBe(0);
    expect(engine.stat("steady_attention").reps).toBe(0);
    expect(engine.start("steady_attention").ok).toBe(true);
    while (engine.state.active) engine.advance(1);
    expect(engine.stat("steady_attention").reps).toBe(1);
    expect(engine.stat("faint_trace").value).toBe(1);
  });

  test("a valid-looking dependency cycle is rejected by actual cold-start play", () => {
    const report = validateContent(changed("jade_slip", record => { record.need = "g.coin >= 6 && g.field_kit > 0"; }));
    expect(report.ok).toBe(false);
    expect(report.errors.some(error => error.includes("Foundation unreachable"))).toBe(true);
    expect(report.missing).toContain("jade_slip");
  });

  test("an unreachable optional home record cannot hide behind successful Foundation routes", () => {
    const report = validateContent(changed("strongbox", record => { record.need = "g.coin >= 1000"; }));
    expect(report.routes.every(route => route.success)).toBe(true);
    expect(report.ok).toBe(false);
    expect(report.missing).toContain("strongbox");
  });

  test("weakening the mandatory core is caught with every supporting pointer satisfied", () => {
    const errors = validateMandatoryCores(changed("settling", record => { record.breakthrough!.core = "g.circulation >= 0"; }));
    expect(errors).toContain("settling: mandatory core is skippable with circulation at zero");
  });

  test("a missing core and an unknown reference are not silently treated as false", () => {
    const coreErrors = validateMandatoryCores(changed("settling", record => { record.breakthrough!.core = "true"; }));
    expect(coreErrors.some(error => error.includes("names no family"))).toBe(true);
    const referenceErrors = validateGrammar(changed("field_kit", record => { record.require = "g.lroe >= 1"; }));
    expect(referenceErrors.some(error => error.includes("unknown record path g.lroe"))).toBe(true);
  });

  test("pacing is measured in the engine, so a slow legal site fails the route budget", () => {
    const slower = changed("clear_channel", record => { record.length = 3000; });
    expect(validateGrammar(slower)).toEqual([]);
    const route = runRoute("channel-only", { records: slower });
    expect(route.success).toBe(true);
    expect(route.foundationSeconds!).toBeGreaterThan(2700);
    const report = validateContent(slower);
    expect(report.errors.some(error => error.includes("over 45 min"))).toBe(true);
  });
});
