import { describe, expect, test } from "bun:test";
import { AGE_PER_SECOND, GameEngine } from "../src/engine";
import { evaluateExpression, expressionReferences, parseExpression } from "../src/expression";
import { records } from "../src/content";
import type { GameRecord, Objective } from "../src/types";

function run(game: GameEngine, id: string, seconds: number, objective?: Objective) {
  expect(game.start(id, objective).ok).toBe(true);
  return game.advance(seconds);
}

function withSlip(): GameEngine {
  const game = new GameEngine(records);
  run(game, "sort_herbs", 60, { kind: "repetitions", id: "sort_herbs", target: 3 });
  run(game, "mill_work", 60, { kind: "repetitions", id: "mill_work", target: 2 });
  expect(game.start("jade_slip").ok).toBe(true);
  return game;
}

describe("restricted shared expression evaluator", () => {
  test("honors arithmetic/boolean precedence and short circuits unavailable references", () => {
    const values: Record<string, number> = { "g.qi": 3, "g.qi.max": 4, "g.lore": 2 };
    const resolve = (path: string) => { if (!(path in values)) throw new Error(path); return values[path]!; };
    expect(evaluateExpression("g.qi < g.qi.max && (g.lore + 2 * 3) == 8", resolve)).toBe(true);
    expect(evaluateExpression("true || g.missing", resolve)).toBe(true);
    expect(expressionReferences("g.qi < g.qi.max && g.qi > 0")).toEqual(["g.qi", "g.qi.max"]);
  });

  test("rejects function calls, assignments, property attacks, nonfinite values and trailing code", () => {
    for (const source of ["g.qi = 9", "alert(1)", "g.__proto__", "g.qi; true", "1e999", "(1 + 2"]) {
      expect(() => parseExpression(source)).toThrow();
    }
    expect(() => evaluateExpression("1 / 0", () => 0)).toThrow();
  });
});

describe("activity and wall-clock accounting", () => {
  test("meaningful discovery stops a larger objective and banks only unused wall time", () => {
    const game = new GameEngine(records);
    const result = run(game, "sort_herbs", 100, { kind: "repetitions", id: "sort_herbs", target: 10 });
    expect(result.activitySeconds).toBe(60);
    expect(result.bankedSeconds).toBe(40);
    expect(game.stat("sort_herbs").reps).toBe(3);
    expect(game.state.active).toBeNull();
    expect(game.visible("jade_slip")).toBe(true);
    const age = game.state.age;
    game.advance(100);
    expect(game.state.age).toBe(age);
    expect(game.state.bank.seconds).toBe(140);
  });

  test("subsecond wall time survives calls and does not create duplicate bank credit", () => {
    const game = new GameEngine(records);
    expect(game.start("mill_work").ok).toBe(true);
    game.advance(0.4);
    expect(game.state.activitySeconds).toBe(0);
    expect(game.state.wallRemainder).toBeCloseTo(0.4);
    game.advance(0.6);
    expect(game.state.activitySeconds).toBe(1);
    expect(game.state.bank.seconds).toBe(0);
    game.advance(29.25);
    expect(game.stat("mill_work").reps).toBe(1);
    expect(game.state.activitySeconds).toBe(30);
    expect(game.state.bank.seconds).toBeCloseTo(0.25);
    expect(game.state.wallRemainder).toBe(0);
  });

  test("idle bank saturates without aging; a new objective never inherits acceleration", () => {
    const game = new GameEngine(records);
    game.advance(5000);
    expect(game.state.bank.seconds).toBe(3600);
    expect(game.state.age).toBe(18);
    expect(game.start("mill_work", { kind: "repetitions", id: "mill_work", target: 2 }).ok).toBe(true);
    expect(game.accelerate().spentSeconds).toBe(60);
    expect(game.state.active).toBeNull();
    expect(game.state.bank.seconds).toBe(3540);
    expect(game.state.age).toBeCloseTo(18 + 60 * AGE_PER_SECOND);
    expect(game.start("mill_work").ok).toBe(true);
    game.advance(1);
    expect(game.state.active?.progress).toBe(1);
    expect(game.state.bank.seconds).toBe(3540);
  });

  test("exhausted bank leaves unfinished work running normally", () => {
    const game = new GameEngine(records);
    game.advance(10);
    game.start("mill_work");
    expect(game.accelerate().spentSeconds).toBe(10);
    expect(game.state.active?.progress).toBe(10);
    expect(game.state.bank.seconds).toBe(0);
    expect(game.advance(20).activitySeconds).toBe(20);
    expect(game.state.active).toBeNull();
    expect(game.stat("coin").value).toBe(3);
  });

  test("one task runs, objectives cannot exceed caps, and failed starts leave work intact", () => {
    const game = withSlip();
    expect(game.start("mill_work").ok).toBe(true);
    game.advance(5);
    expect(game.start("fragment_notes", { kind: "level", id: "lore", target: 4 }).ok).toBe(false);
    expect(game.state.active?.id).toBe("mill_work");
    expect(game.start("fragment_notes").ok).toBe(true);
    expect(game.state.active?.id).toBe("fragment_notes");
    expect(game.state.active?.progress).toBe(0);
  });

  test("an unrelated objective is refused before it can spend time or bank", () => {
    const game = withSlip();
    game.advance(100);
    const saved = game.snapshot();
    expect(game.start("mill_work", { kind: "level", id: "lore", target: 1 }).ok).toBe(false);
    expect(game.start("mill_work", { kind: "resource", id: "herbs", target: 10 }).ok).toBe(false);
    expect(game.snapshot()).toEqual(saved);
    expect(game.accelerate().spentSeconds).toBe(0);
  });

  test("the save validator can reject a completed finite run and accept partial progress", () => {
    const game = new GameEngine(records);
    const objective: Objective = { kind: "repetitions", id: "mill_work", target: 1 };
    expect(game.objectiveAvailability("mill_work", objective, 29.5).ok).toBe(true);
    expect(game.objectiveAvailability("mill_work", objective, 30).ok).toBe(false);
    expect(game.objectiveAvailability("mill_work", objective, -1).ok).toBe(false);
    expect(game.objectiveAvailability("mill_work", objective, Infinity).ok).toBe(false);
    expect(game.objectiveAvailability("coin", { kind: "resource", id: "coin", target: 3 }).ok).toBe(false);
  });
});

describe("resources, runways and declarative records", () => {
  test("cap income clamps and the cap line names a newly visible external raiser", () => {
    const game = new GameEngine(records);
    run(game, "mill_work", 300, { kind: "repetitions", id: "mill_work", target: 10 });
    expect(game.stat("coin").value).toBe(20);
    expect(game.visible("coin_pouch")).toBe(true);
    expect(game.state.log.filter(entry => entry.kind === "cap" && entry.text.startsWith("Coin"))).toHaveLength(1);
    expect(game.state.log.find(entry => entry.kind === "cap")?.text).toContain("larger coin pouch");
    expect(game.start("coin_pouch").ok).toBe(true);
    expect(game.stat("coin").value).toBe(5);
    expect(game.stat("coin").max).toBe(50);
    expect(game.visible("coin_pouch")).toBe(true);
  });

  test("the tenth wage is unchanged and later runs use the permanent curve", () => {
    const modified = structuredClone(records) as GameRecord[];
    modified.find(record => record.id === "coin")!.initial!.max = 1000;
    const game = new GameEngine(modified);
    run(game, "mill_work", 300, { kind: "repetitions", id: "mill_work", target: 10 });
    expect(game.stat("coin").value).toBe(30);
    expect(game.stat("mill_work").yield).toBe(1);
    run(game, "mill_work", 600, { kind: "repetitions", id: "mill_work", target: 30 });
    expect(game.stat("coin").value).toBe(110);
    run(game, "mill_work", 30);
    expect(game.stat("coin").value).toBe(115);
  });

  test("family cost is 60 times the next level; each Qi Sense level raises its reservoir", () => {
    const game = withSlip();
    run(game, "breath_gathering", 60);
    expect(game.stat("qi_sense").value).toBe(1);
    expect(game.stat("qi").max).toBe(3);
    expect(game.stat("qi").value).toBe(2);
    run(game, "breath_gathering", 119);
    expect(game.stat("qi_sense").value).toBe(1);
    expect(game.stat("qi_sense").exp).toBe(119);
    game.advance(1);
    expect(game.stat("qi_sense").value).toBe(2);
    expect(game.stat("qi_sense").exp).toBe(0);
    expect(game.stat("qi").max).toBe(4);
    expect(game.state.active).toBeNull();
  });

  test("arrangement speed improves real practice and a full family discards surplus experience", () => {
    const game = withSlip();
    run(game, "mill_work", 90, { kind: "repetitions", id: "mill_work", target: 5 });
    expect(game.start("practice_mat").ok).toBe(true);
    run(game, "breath_gathering", 48);
    expect(game.stat("qi_sense").value).toBe(1);
    expect(game.stat("breath_gathering").rate).toBe(1.25);
    run(game, "breath_gathering", 240, { kind: "level", id: "qi_sense", target: 3 });
    expect(game.stat("qi_sense").value).toBe(3);
    expect(game.stat("qi_sense").exp).toBe(0);
  });

  test("first hollow sitting raises the cap before adding its experience", () => {
    const game = withSlip();
    run(game, "breath_gathering", 360, { kind: "level", id: "qi_sense", target: 3 });
    run(game, "fernhollow_observe", 120);
    run(game, "sit_fernhollow", 180);
    expect(game.stat("qi_sense").max).toBe(5);
    expect(game.stat("qi_sense").exp).toBe(60);
  });

  test("steady attention opens once, pays per-level work speed and pauses at its trace", () => {
    const game = withSlip();
    run(game, "breath_gathering", 360, { kind: "level", id: "qi_sense", target: 3 });
    run(game, "fernhollow_observe", 120);
    run(game, "sit_fernhollow", 540, { kind: "repetitions", id: "sit_fernhollow", target: 3 });
    expect(game.stat("circulation").open).toBe(false);
    const result = run(game, "steady_attention", 360, { kind: "level", id: "circulation", target: 3 });
    expect(result.activitySeconds).toBe(180);
    expect(game.stat("circulation").open).toBe(true);
    expect(game.stat("circulation").value).toBe(2);
    expect(game.stat("faint_trace").value).toBe(1);
    expect(game.stat("steady_attention").reps).toBe(2);
    expect(game.stat("mill_work").length).toBe(20);
    expect(game.state.active).toBeNull();
    run(game, "steady_attention", 180);
    expect(game.stat("circulation").value).toBe(3);
    expect(game.stat("faint_trace").value).toBe(1);
    expect(game.stat("mill_work").length).toBe(15);
  });

  test("space and purchase bills are checked atomically and home growth retains arrangements", () => {
    const game = withSlip();
    game.stat("coin").value = 20;
    expect(game.start("practice_mat").ok).toBe(true);
    game.stat("clear_channel").value = 1;
    game.stat("stone").value = 8;
    game.advance(0); // Visibility changes are normally reconciled by real actions.
    game.state.visibleIds.push("channel_arrangement");
    expect(game.start("channel_arrangement").ok).toBe(false);
    expect(game.stat("stone").value).toBe(8);
    expect(game.stat("home_space").value).toBe(1);
    game.stat("coin").max = 50;
    game.stat("coin").value = 40;
    game.stat("timber").value = 6;
    expect(game.start("lean_to").ok).toBe(true);
    expect(game.stat("home_space").max).toBe(4);
    expect(game.stat("practice_mat").value).toBe(1);
    expect(game.state.disabledIds).toContain("hayloft");
    expect(game.start("channel_arrangement").ok).toBe(true);
    expect(game.stat("home_space").value).toBe(3);
    expect(game.stat("stone").value).toBe(4);
  });

  test("per-run costs charge once, and goal updates do not repeat the initial bill", () => {
    const fixture: GameRecord[] = [
      { id: "coin", kind: "resource", initial: { value: 10, max: 20 } },
      { id: "craft", kind: "task", length: 2, cost: { coin: 1 } },
    ];
    const game = new GameEngine(fixture);
    game.start("craft");
    expect(game.stat("coin").value).toBe(9);
    game.start("craft", { kind: "repetitions", id: "craft", target: 3 });
    expect(game.stat("coin").value).toBe(9);
    game.advance(6);
    expect(game.stat("craft").reps).toBe(3);
    expect(game.stat("coin").value).toBe(7);
  });

  test("a drained reservoir stops before another activity second and banks the remainder", () => {
    const fixture: GameRecord[] = [
      { id: "qi", kind: "resource", initial: { value: 1, max: 2 } },
      { id: "focus", kind: "family", initial: { value: 0, max: 3 } },
      { id: "practice", kind: "task", length: "continuous", train: "focus", run: { qi: 1 }, effect: { "focus.exp": 1 } },
    ];
    const game = new GameEngine(fixture);
    const result = run(game, "practice", 5);
    expect(result.activitySeconds).toBe(1);
    expect(result.bankedSeconds).toBe(4);
    expect(game.stat("qi").value).toBe(0);
    expect(game.stat("focus").exp).toBe(1);
    expect(game.state.active).toBeNull();
  });

  test("run and strain together cannot overdraw the same reservoir", () => {
    const fixture: GameRecord[] = [
      { id: "qi", kind: "resource", initial: { value: 1, max: 2 } },
      { id: "work", kind: "task", length: 2, run: { qi: 1 }, strain: { qi: 1 } },
    ];
    const game = new GameEngine(fixture);
    const result = run(game, "work", 3);
    expect(result.activitySeconds).toBe(0);
    expect(result.bankedSeconds).toBe(3);
    expect(game.stat("qi").value).toBe(1);
  });
});

describe("checkpoint and lifespan boundaries", () => {
  test("retry restores the exact world and refunds spending while retaining later accrual once", () => {
    const game = new GameEngine(records);
    game.advance(100);
    game.start("mill_work", { kind: "repetitions", id: "mill_work", target: 2 });
    game.accelerate();
    game.advance(200);
    expect(game.state.bank).toEqual({ seconds: 240, cap: 3600, spentSinceCheckpoint: 60 });
    game.retry();
    expect(game.state.bank).toEqual({ seconds: 300, cap: 3600, spentSinceCheckpoint: 0 });
    expect(game.stat("coin").value).toBe(0);
    expect(game.stat("mill_work").reps).toBe(0);
    expect(game.state.age).toBe(18);
    expect(game.state.activitySeconds).toBe(0);
    expect(game.state.visibleIds).toEqual(game.state.checkpoint.world.visibleIds);
    game.retry();
    expect(game.state.bank.seconds).toBe(300);
    game.start("mill_work");
    game.accelerate();
    game.retry();
    expect(game.state.bank.seconds).toBe(300);
  });

  test("Foundation requires its core and creates a post-reward, paused checkpoint", () => {
    const game = withSlip();
    game.stat("circulation").open = true;
    game.stat("circulation").value = 1;
    game.stat("qi_sense").value = 3;
    game.stat("lore").value = 2;
    // A channel source keeps this focused fixture clear of an unfired hollow discovery.
    game.stat("clear_channel").value = 1;
    game.stat("clear_channel").reps = 1;
    game.stat("channel_arrangement").value = 1;
    game.state.eventIds.push("channel_hum");
    game.stat("qi").value = game.stat("qi").max;
    game.stat("herbs").value = 12;
    game.state.visibleIds.push("settling");
    expect(game.availability("settling").ok).toBe(false);
    expect(game.availability("settling").reason).toContain("Circulation 2");
    game.stat("circulation").value = 2;
    game.advance(200);
    expect(game.start("settling").ok).toBe(true);
    expect(game.stat("herbs").value).toBe(2);
    expect(game.accelerate().spentSeconds).toBe(120);
    expect(game.stat("foundation").value).toBe(1);
    expect(game.state.lifespan).toBe(85);
    expect(game.state.bank.cap).toBe(21600);
    expect(game.state.bank.spentSinceCheckpoint).toBe(0);
    expect(game.state.active).toBeNull();
    expect(game.state.checkpoint.world.stats.foundation!.value).toBe(1);
    expect(game.state.checkpoint.world.active).toBeNull();
    const bank = game.state.bank.seconds;
    game.retry();
    expect(game.state.bank.seconds).toBe(bank);
    expect(game.stat("foundation").value).toBe(1);
    expect(game.stat("herbs").value).toBe(2);
  });

  test("lifespan stops acceleration before overrun and never spends the unused bank", () => {
    const game = new GameEngine(records);
    game.state.age = game.state.lifespan - 2 * AGE_PER_SECOND;
    game.advance(100);
    game.start("mill_work");
    const result = game.accelerate();
    expect(result.spentSeconds).toBe(2);
    expect(game.state.active).toBeNull();
    expect(game.state.age).toBeCloseTo(game.state.lifespan);
    expect(game.state.bank.seconds).toBe(98);
    expect(game.state.log.at(-1)?.kind).toBe("pause");
    game.retry();
    expect(game.state.age).toBe(18);
    expect(game.state.bank.seconds).toBe(100);
  });

  test("an accelerated breakthrough cannot duplicate an unfinished fractional wall tick on retry", () => {
    const fixture: GameRecord[] = [
      { id: "foundation", kind: "flag", initial: { max: 1 } },
      { id: "settling", kind: "breakthrough", length: 2, result: { foundation: 1 } },
    ];
    const game = new GameEngine(fixture);
    game.advance(10);
    game.start("settling");
    game.advance(0.5);
    expect(game.accelerate().bankedSeconds).toBeCloseTo(0.5);
    expect(game.state.bank.seconds).toBeCloseTo(8.5);
    expect(game.state.checkpoint.world.wallRemainder).toBe(0);
    game.retry();
    game.advance(0);
    expect(game.state.bank.seconds).toBeCloseTo(8.5);
    expect(game.state.wallRemainder).toBe(0);
    game.retry();
    expect(game.state.bank.seconds).toBeCloseTo(8.5);
  });

  test("snapshots and constructor restores do not alias mutable running state", () => {
    const game = withSlip();
    const saved = game.snapshot();
    const restored = new GameEngine(records, saved);
    run(restored, "fragment_notes", 60);
    expect(game.stat("lore").value).toBe(0);
    expect(saved.stats.lore!.value).toBe(0);
    expect(restored.stat("lore").value).toBe(1);
    expect(JSON.parse(JSON.stringify(restored.snapshot()))).toEqual(restored.snapshot());
  });
});
