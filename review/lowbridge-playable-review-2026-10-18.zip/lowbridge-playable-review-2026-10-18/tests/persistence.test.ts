import { describe, expect, test } from 'bun:test';
import { GameEngine } from '../src/engine';
import { records } from '../src/content';
import { decodeSave, makeSave } from '../src/persistence';

describe('portable saves', () => {
  test('roundtrip retains a running objective and independent checkpoint', () => {
    const game = new GameEngine(records);
    game.start('mill_work', { kind: 'resource', id: 'coin', target: 20 });
    game.advance(11.25);
    const encoded = makeSave(game.state, 1000);
    const decoded = decodeSave(JSON.stringify(encoded), records);
    const loaded = new GameEngine(records, decoded.state);
    expect(loaded.state).toEqual(game.state);
    loaded.advance(19);
    expect(loaded.stat('coin').value).toBe(3);
    expect(loaded.state.checkpoint.world.stats.coin.value).toBe(0);
    expect(decoded.state.stats.coin.value).toBe(0);
  });

  test('rejects corrupt current state, checkpoint and incompatible files before mutation', () => {
    const game = new GameEngine(records);
    const before = game.snapshot();
    const save = () => makeSave(game.state, 1000);
    const negative = save(); negative.state.bank.seconds = -1;
    const badCheckpoint = save(); badCheckpoint.state.checkpoint.world.stats.coin.max = -20;
    const missingRecord = save(); delete missingRecord.state.stats.coin;
    const malformedObjective = save();
    malformedObjective.state.active = { id: 'mill_work', progress: 2, objective: { kind: 'resource', id: 'no_such_resource', target: 20 } };
    const wrongVersion = { ...save(), version: 2 };
    const unrelatedObjective = save();
    unrelatedObjective.state.active = { id: 'mill_work', progress: 2, objective: { kind: 'level', id: 'lore', target: 1 } };
    const invalidProgress = save();
    invalidProgress.state.active = { id: 'mill_work', progress: 999, objective: { kind: 'repetitions', id: 'mill_work', target: 1 } };
    const zeroDuration = save(); zeroDuration.state.stats.mill_work.length = 0;
    for (const value of [negative, badCheckpoint, missingRecord, malformedObjective, unrelatedObjective, invalidProgress, zeroDuration, wrongVersion, { version: 1 }, '{broken']) {
      expect(() => decodeSave(value, records)).toThrow();
    }
    expect(game.state).toEqual(before);
  });

  test('export is a snapshot, so continuing the game cannot change the file being written', () => {
    const game = new GameEngine(records);
    const saved = makeSave(game.state, 1000);
    game.advance(100);
    expect(saved.state.bank.seconds).toBe(0);
    expect(game.state.bank.seconds).toBe(100);
  });
});
