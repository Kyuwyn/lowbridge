import { evaluateCondition, evaluateExpression } from "./expression";
import type { AdvanceResult, Availability, Changes, GameRecord, GameState, LogEntry, Objective, Stat, WorldState } from "./types";

export const AGE_PER_SECOND = 0.25 / 3600;
const UNBOUNDED = 1_000_000_000_000;
const EPSILON = 1e-9;
const passiveKinds = new Set(["resource", "family", "flag", "lead"]);
const oneShotKinds = new Set(["purchase", "arrangement", "home", "class", "breakthrough", "teaching", "recipe", "technique"]);
const clone = <T>(value: T): T => structuredClone(value);

/** One authoritative simulation shared by the browser, offline settlement and tests. */
export class GameEngine {
  readonly records: readonly GameRecord[];
  state: GameState;
  private readonly byId: Map<string, GameRecord>;
  private pendingCaps = new Set<string>();
  private lastReason: string | undefined;

  constructor(records: readonly GameRecord[], state?: GameState) {
    this.records = records;
    this.byId = new Map(records.map(record => [record.id, record]));
    if (this.byId.size !== records.length) throw new Error("Content contains duplicate record ids.");
    if (state) {
      this.state = clone(state);
      return;
    }
    const stats: Record<string, Stat> = {};
    for (const record of records) {
      stats[record.id] = {
        value: 0,
        max: record.max ?? record.runway ?? (oneShotKinds.has(record.kind) || record.kind === "flag" ? 1 : UNBOUNDED),
        exp: 0, rate: record.kind === "resource" ? 0 : 1, reps: 0, open: true,
        length: typeof record.length === "number" ? record.length : 0,
        yield: 0, ticks: 0, started: false,
        ...record.initial,
      };
    }
    const world: WorldState = {
      stats, active: null, age: 18, lifespan: 80, activitySeconds: 0,
      visibleIds: [], disabledIds: [], eventIds: [], capHits: [], log: [], wallRemainder: 0,
    };
    this.state = {
      ...world,
      bank: { seconds: 0, cap: 3600, spentSinceCheckpoint: 0 },
      checkpoint: { world: clone(world), bankCap: 3600, label: "Arrival in Lowbridge" },
    };
    this.reconcile(false);
    this.createCheckpoint("Arrival in Lowbridge");
  }

  record(id: string): GameRecord {
    const record = this.byId.get(id);
    if (!record) throw new Error(`Unknown record: ${id}`);
    return record;
  }

  stat(id: string): Stat {
    const stat = this.state.stats[id];
    if (!stat || !Object.hasOwn(this.state.stats, id)) throw new Error(`Unknown stat: ${id}`);
    return stat;
  }

  snapshot(): GameState { return clone(this.state); }

  resolve = (path: string): number | boolean => {
    const normalized = path.startsWith("g.") ? path.slice(2) : path;
    if (normalized === "age") return this.state.age;
    if (normalized === "lifespan") return this.state.lifespan;
    if (normalized === "bank" || normalized === "bank.value" || normalized === "bank.seconds") return this.state.bank.seconds;
    if (normalized === "bank.max" || normalized === "bank.cap") return this.state.bank.cap;
    const [id, field = "value", ...rest] = normalized.split(".");
    if (rest.length) throw new Error(`Unsupported stat path: ${path}`);
    const stat = this.stat(id!);
    if (!Object.hasOwn(stat, field)) throw new Error(`Unknown stat field: ${path}`);
    const value = stat[field as keyof Stat];
    return typeof value === "boolean" ? Number(value) : value;
  };

  value(value: number | string): number {
    const result = typeof value === "number" ? value : Number(evaluateExpression(value, this.resolve));
    if (!Number.isFinite(result)) throw new Error("Content produced a non-finite amount.");
    return result;
  }

  condition(expression?: string): boolean { return evaluateCondition(expression, this.resolve); }
  visible(id: string): boolean { return this.state.visibleIds.includes(id); }

  /** Persistence can reuse the action contract after validating the JSON's shape. */
  objectiveAvailability(id: string, objective: Objective, progress?: number): Availability {
    const record = this.record(id);
    if (record.length === undefined || passiveKinds.has(record.kind)) return { ok: false, reason: "This record cannot have an active objective." };
    if (progress !== undefined && (!Number.isFinite(progress) || progress < 0 || (record.length !== "continuous" && progress + EPSILON >= this.stat(id).length))) {
      return { ok: false, reason: "The saved activity progress is outside its current duration." };
    }
    const reason = this.objectiveProblem(record, objective);
    return reason ? { ok: false, reason } : { ok: true, reason: "Ready." };
  }

  availability(id: string): Availability {
    const record = this.record(id), stat = this.stat(id);
    const fail = (reason: string): Availability => ({ ok: false, reason });
    if (!this.visible(id)) return fail("This has not been discovered.");
    if (this.state.disabledIds.includes(id)) return fail("This chapter has closed.");
    if (passiveKinds.has(record.kind)) return fail(record.kind === "lead" ? "This lead continues beyond the opening." : "This is a capability, not an activity.");
    if (stat.value >= stat.max || stat.reps >= stat.max) return fail("Completed.");
    if (record.breakthrough) {
      if (!this.condition(record.breakthrough.core)) return fail(record.breakthrough.coreLabel ?? "The core method is not ready.");
      const ready = record.breakthrough.pointers.filter(pointer => this.condition(pointer.when)).length;
      if (ready < record.breakthrough.required) return fail(`${ready} of ${record.breakthrough.required} supporting conditions are ready.`);
    }
    if (!this.condition(record.need)) return fail(record.needtext ?? "The requirements are not met.");
    if (record.space && this.stat("home_space").max - this.stat("home_space").value < record.space) {
      return fail(`${record.space} free spans of floor are needed.`);
    }
    const payment = this.payment(record);
    for (const [resource, amount] of Object.entries(payment)) {
      if (this.stat(resource).value + EPSILON < amount) return fail(`${this.record(resource).name ?? resource}: ${amount} needed.`);
    }
    if (record.length !== undefined && this.state.age + AGE_PER_SECOND > this.state.lifespan + EPSILON) {
      return fail("Your remaining lifespan cannot carry another moment of activity. Retry from the checkpoint.");
    }
    return { ok: true, reason: "Ready." };
  }

  defaultObjective(id: string): Objective {
    const record = this.record(id), stat = this.stat(id);
    if (record.length === "continuous") {
      if (record.train && this.stat(record.train).value < this.stat(record.train).max) {
        return { kind: "level", id: record.train, target: this.stat(record.train).value + 1 };
      }
      const outputs = { ...record.effect, ...Object.assign({}, ...Object.values(record.every ?? {})) } as Changes;
      const resource = Object.keys(outputs).find(path => !path.includes(".") && this.byId.get(path)?.kind === "resource" && this.value(outputs[path]!) > 0 && this.stat(path).value < this.stat(path).max);
      if (resource) return { kind: "resource", id: resource, target: this.stat(resource).max };
      if (record.train) return { kind: "level", id: record.train, target: this.stat(record.train).max };
    }
    return { kind: "repetitions", id, target: stat.reps + 1 };
  }

  start(id: string, objective?: Objective): Availability {
    const record = this.record(id);
    // Changing the objective of the running action does not buy its first run twice.
    if (this.state.active?.id === id) {
      const chosen = objective ?? this.defaultObjective(id);
      const invalid = this.objectiveProblem(record, chosen);
      if (invalid) return { ok: false, reason: invalid };
      this.state.active.objective = clone(chosen);
      return { ok: true, reason: "Objective updated." };
    }
    const available = this.availability(id);
    if (!available.ok) return available;
    const chosen = objective ?? this.defaultObjective(id);
    if (record.length !== undefined) {
      const invalid = this.objectiveProblem(record, chosen);
      if (invalid) return { ok: false, reason: invalid };
    }
    this.stop();
    this.pay(record);
    const stat = this.stat(id);
    if (!stat.started) {
      stat.started = true;
      this.apply(record.onStart);
    }
    if (record.length === undefined) {
      this.complete(record);
      this.log("purchase", `${record.name ?? id} is now part of your life in Lowbridge.`);
      this.reconcile();
    } else {
      this.state.active = { id, progress: 0, objective: clone(chosen) };
      this.reconcile();
    }
    return { ok: true, reason: "Started." };
  }

  stop(): void {
    this.state.active = null;
    if (this.state.wallRemainder) {
      this.creditBank(this.state.wallRemainder);
      this.state.wallRemainder = 0;
    }
  }

  /** Wall time advances the chosen activity first; only unused time enters the bank. */
  advance(seconds: number): AdvanceResult {
    this.requireSeconds(seconds);
    this.lastReason = undefined;
    const result: AdvanceResult = { activitySeconds: 0, bankedSeconds: 0, spentSeconds: 0 };
    let remaining = seconds + this.state.wallRemainder;
    this.state.wallRemainder = 0;
    while (this.state.active && remaining + EPSILON >= 1) {
      if (!this.tick()) break;
      remaining = Math.max(0, remaining - 1);
      result.activitySeconds++;
    }
    if (this.state.active) this.state.wallRemainder = Math.max(0, remaining);
    else result.bankedSeconds = this.creditBank(Math.max(0, remaining));
    if (this.lastReason) result.reason = this.lastReason;
    return result;
  }

  /** Promptly spend existing bank on this objective only. No new wall time is credited. */
  accelerate(): AdvanceResult {
    this.lastReason = undefined;
    const startingBank = this.state.bank.seconds;
    const result: AdvanceResult = { activitySeconds: 0, bankedSeconds: 0, spentSeconds: 0 };
    while (this.state.active && this.state.bank.seconds + EPSILON >= 1) {
      const before = this.state.activitySeconds;
      // Debit before ticking so a breakthrough checkpoint includes this final spent second.
      this.state.bank.seconds = Math.max(0, this.state.bank.seconds - 1);
      this.state.bank.spentSinceCheckpoint++;
      if (!this.tick()) {
        this.state.bank.seconds = Math.min(this.state.bank.cap, this.state.bank.seconds + 1);
        this.state.bank.spentSinceCheckpoint--;
        break;
      }
      result.activitySeconds += this.state.activitySeconds - before;
      result.spentSeconds++;
    }
    if (!this.state.active && this.state.wallRemainder) {
      this.creditBank(this.state.wallRemainder);
      this.state.wallRemainder = 0;
    }
    result.bankedSeconds = Math.max(0, this.state.bank.seconds + result.spentSeconds - startingBank);
    result.reason = this.lastReason ?? (this.state.active ? "The bank is empty; the activity continues at ordinary speed." : undefined);
    return result;
  }

  retry(): void {
    const checkpoint = clone(this.state.checkpoint);
    const balance = Math.min(checkpoint.bankCap, this.state.bank.seconds + this.state.bank.spentSinceCheckpoint + this.state.wallRemainder);
    this.state = {
      ...clone(checkpoint.world),
      bank: { seconds: balance, cap: checkpoint.bankCap, spentSinceCheckpoint: 0 },
      checkpoint,
    };
    this.pendingCaps.clear();
    this.log("retry", `Returned to ${checkpoint.label}. Bank spent since this checkpoint has been restored.`);
  }

  capRaisers(id: string): GameRecord[] {
    const target = `${id}.max`;
    return this.records.filter(record => {
      if (!this.visible(record.id) || this.state.disabledIds.includes(record.id)) return false;
      const stat = this.stat(record.id);
      if (record.kind === "family") {
        return stat.open && stat.value < stat.max && this.value(record.perLevel?.[target] ?? 0) > 0;
      }
      if (stat.value >= stat.max || stat.reps >= stat.max) return false;
      const direct = [record.mod, record.result, record.onStart].some(changes => this.value(changes?.[target] ?? 0) > 0);
      const thresholds = Object.entries(record.at ?? {}).some(([threshold, changes]) => Number(threshold) > (record.length === "continuous" ? stat.ticks : stat.reps) && this.value(changes[target] ?? 0) > 0);
      const repeated = Object.values(record.every ?? {}).some(changes => this.value(changes[target] ?? 0) > 0);
      return direct || thresholds || repeated;
    });
  }

  private objectiveProblem(record: GameRecord, objective: Objective): string | undefined {
    if (!this.byId.has(objective.id) || !Number.isFinite(objective.target) || objective.target < 0 || objective.target > UNBOUNDED) return "The objective is invalid.";
    if (!["repetitions", "level", "resource"].includes(objective.kind)) return "The objective kind is invalid.";
    if (objective.kind !== "resource" && !Number.isInteger(objective.target)) return "Levels and repetitions need a whole-number objective.";
    if (objective.kind === "repetitions" && (objective.id !== record.id || record.length === "continuous")) return "Choose this activity's repetitions or its trained family.";
    if (objective.kind === "level" && this.record(objective.id).kind !== "family") return "A level objective needs a technique family.";
    if (objective.kind === "resource" && this.record(objective.id).kind !== "resource") return "A resource objective needs a resource.";
    if (objective.kind === "repetitions" && objective.target > this.stat(record.id).max) return "This activity cannot be completed that many times.";
    if (objective.kind === "level" && objective.target > this.stat(objective.id).max) return "That objective lies beyond the family's current cap.";
    if (objective.kind === "resource" && objective.target > this.stat(objective.id).max) return "That objective lies beyond the resource's current cap.";
    if (objective.kind !== "repetitions") {
      const changes = [record.effect, record.result, ...Object.values(record.at ?? {}), ...Object.values(record.every ?? {})];
      const paths = objective.kind === "level" ? [`${objective.id}.exp`] : [objective.id, `${objective.id}.value`];
      const directlyEarned = changes.some(change => paths.some(path => this.value(change?.[path] ?? 0) > 0));
      const passiveIncome = objective.kind === "resource" && this.stat(objective.id).open && this.stat(objective.id).rate > 0;
      if (!directlyEarned && !passiveIncome) return "This activity cannot advance that objective.";
    }
    const current = objective.kind === "repetitions" ? this.stat(objective.id).reps : this.stat(objective.id).value;
    return objective.target <= current + EPSILON ? "That objective is already complete." : undefined;
  }

  private reached(objective: Objective): boolean {
    const stat = this.stat(objective.id);
    return (objective.kind === "repetitions" ? stat.reps : stat.value) + EPSILON >= objective.target;
  }

  private tick(): boolean {
    const active = this.state.active;
    if (!active) return false;
    const record = this.record(active.id), stat = this.stat(active.id);
    if (this.reached(active.objective)) { this.finishObjective(); return false; }
    if (this.state.age + AGE_PER_SECOND > this.state.lifespan + EPSILON) {
      this.pause("Your remaining lifespan cannot carry another moment of activity. The checkpoint remains.");
      return false;
    }
    if (this.state.disabledIds.includes(record.id) || (record.length === "continuous" && !this.condition(record.need))) {
      this.pause(record.needtext ?? "This activity has reached its current limit.");
      return false;
    }
    const drain: Record<string, number> = {};
    for (const changes of [record.run, record.strain]) {
      for (const [id, amount] of Object.entries(changes ?? {})) drain[id] = (drain[id] ?? 0) + this.value(amount);
    }
    for (const [id, amount] of Object.entries(drain)) {
      const resource = this.stat(id);
      if (resource.value + (resource.open ? resource.rate : 0) + EPSILON < amount) {
        this.pause(`${this.record(id).name ?? id} cannot sustain this activity.`);
        return false;
      }
    }
    this.state.activitySeconds++;
    this.state.age = Math.min(this.state.lifespan, this.state.age + AGE_PER_SECOND);
    stat.ticks++;
    const levelBefore = record.train ? this.stat(record.train).value : 0;
    for (const resource of this.records) {
      const current = this.stat(resource.id);
      if (resource.kind === "resource" && current.open && current.rate) this.change(resource.id, current.rate);
    }
    this.apply(record.run, -1);
    this.apply(record.strain, -1);
    this.apply(record.effect, stat.rate);
    if (record.length === "continuous") {
      active.progress++;
      this.thresholds(record, stat.ticks);
      if (record.train) {
        const gained = this.stat(record.train).value - levelBefore;
        stat.reps += gained;
        stat.value = Math.min(stat.max, stat.value + gained);
      }
      if (this.reached(active.objective)) this.finishObjective();
    } else {
      active.progress += stat.rate;
      while (this.state.active === active && active.progress + EPSILON >= stat.length) {
        active.progress = Math.max(0, active.progress - stat.length);
        this.complete(record);
        if (this.reached(active.objective)) this.finishObjective();
        this.reconcile();
        if (record.kind === "breakthrough") {
          // Acceleration may have begun halfway through an ordinary tick. Settle
          // that unused fraction before the exact checkpoint can preserve it.
          this.stop();
          this.createCheckpoint(record.breakthrough?.title ?? record.name ?? record.id);
          break;
        }
        if (this.state.active === active) {
          const available = this.availability(record.id);
          if (!available.ok) this.pause(available.reason);
          else this.pay(record);
        }
      }
    }
    this.reconcile();
    if (this.state.active && this.state.age + AGE_PER_SECOND > this.state.lifespan + EPSILON) {
      this.pause("Your remaining lifespan cannot carry another moment of activity. The checkpoint remains.");
    }
    return true;
  }

  private complete(record: GameRecord): void {
    const stat = this.stat(record.id), previousYield = stat.yield;
    stat.reps++;
    stat.value = Math.min(stat.max, stat.value + 1);
    // Cap changes precede site experience; wage improvements apply to the following run.
    this.thresholds(record, stat.reps);
    for (const [path, amount] of Object.entries(record.result ?? {})) {
      const bonus = !path.includes(".") && this.byId.get(path)?.kind === "resource" && this.value(amount) > 0 ? previousYield : 0;
      this.change(path, this.value(amount) + bonus);
    }
    if (stat.reps === 1) {
      this.apply(record.mod);
      if (record.space) this.change("home_space", record.space);
      for (const id of record.disable ?? []) if (!this.state.disabledIds.includes(id)) this.state.disabledIds.push(id);
    }
    if (record.pauseOnComplete) this.pause(`${record.name ?? record.id} is complete. There is a new choice to consider.`);
  }

  private thresholds(record: GameRecord, count: number): void {
    this.apply(record.at?.[String(count)]);
    for (const [period, changes] of Object.entries(record.every ?? {})) {
      if (Number(period) > 0 && count % Number(period) === 0) this.apply(changes);
    }
  }

  private payment(record: GameRecord): Record<string, number> {
    const result: Record<string, number> = {};
    for (const changes of [record.buy, record.cost]) {
      for (const [id, amount] of Object.entries(changes ?? {})) {
        const evaluated = this.value(amount);
        if (evaluated < 0) throw new Error(`Negative purchase cost in ${record.id}.`);
        result[id] = (result[id] ?? 0) + evaluated;
      }
    }
    return result;
  }

  private pay(record: GameRecord): void {
    for (const [id, amount] of Object.entries(this.payment(record))) this.change(id, -amount);
  }

  private apply(changes?: Changes, multiplier = 1): void {
    const evaluated = Object.entries(changes ?? {}).map(([path, amount]) => [path, this.value(amount) * multiplier] as const);
    // Opening a family and raising its cap must precede any experience in the same effect.
    evaluated.sort(([a], [b]) => Number(b.endsWith(".max") || b.endsWith(".open")) - Number(a.endsWith(".max") || a.endsWith(".open")));
    for (const [path, amount] of evaluated) this.change(path, amount);
  }

  private change(path: string, amount: number): void {
    if (!Number.isFinite(amount)) throw new Error(`Non-finite change to ${path}.`);
    if (path === "lifespan") { this.state.lifespan = Math.max(this.state.age, this.state.lifespan + amount); return; }
    if (path === "age") { this.state.age = Math.max(0, Math.min(this.state.lifespan, this.state.age + amount)); return; }
    if (path === "bank.max" || path === "bank.cap") {
      this.state.bank.cap = Math.max(0, this.state.bank.cap + amount);
      this.state.bank.seconds = Math.min(this.state.bank.seconds, this.state.bank.cap);
      return;
    }
    if (path === "bank" || path === "bank.value" || path === "bank.seconds") {
      this.state.bank.seconds = Math.max(0, Math.min(this.state.bank.cap, this.state.bank.seconds + amount)); return;
    }
    const [id, field = "value", ...rest] = path.split(".");
    if (rest.length) throw new Error(`Unsupported modifier path: ${path}`);
    const stat = this.stat(id!), record = this.record(id!);
    if (field === "open" || field === "started") { if (amount) stat[field] = amount > 0; return; }
    if (field === "exp") {
      if (record.kind !== "family" || !stat.open || stat.value >= stat.max) return;
      stat.exp = Math.max(0, stat.exp + amount * stat.rate);
      while (stat.value < stat.max && stat.exp + EPSILON >= 60 * (stat.value + 1)) {
        stat.exp = Math.max(0, stat.exp - 60 * (stat.value + 1));
        stat.value++;
        this.apply(record.perLevel);
        this.log("completion", `${record.name ?? id} reaches level ${stat.value}.`);
      }
      if (stat.value >= stat.max) { stat.exp = 0; this.pendingCaps.add(id!); }
      return;
    }
    if (field === "value") {
      stat.value = Math.max(0, Math.min(stat.max, stat.value + amount));
      if (amount > 0 && stat.value >= stat.max && record.kind === "resource") this.pendingCaps.add(id!);
      return;
    }
    if (!Object.hasOwn(stat, field)) throw new Error(`Unsupported modifier field: ${path}`);
    const numeric = field as "max" | "rate" | "reps" | "length" | "yield" | "ticks";
    stat[numeric] = Math.max(field === "length" && record.length !== "continuous" ? 1 : 0, stat[numeric] + amount);
    if (field === "max") {
      stat.value = Math.min(stat.value, stat.max);
      if (record.kind === "family" && stat.value >= stat.max) stat.exp = 0;
    }
  }

  private reconcile(logReveals = true): void {
    // Event changes can reveal another event, but every event can fire only once.
    let changed: boolean;
    do {
      changed = false;
      for (const record of this.records) {
        if (!this.visible(record.id) && this.condition(record.require)) {
          this.state.visibleIds.push(record.id);
          if (logReveals && record.require) this.log("discovery", `${record.name ?? record.id} is now known.`);
          if (logReveals && record.pauseOnReveal) this.pause(`A new possibility has appeared: ${record.name ?? record.id}.`);
        }
        for (const event of record.events ?? []) {
          if (!this.state.eventIds.includes(event.id) && this.condition(event.when)) {
            this.state.eventIds.push(event.id);
            this.apply(event.changes);
            this.log("discovery", event.text);
            if (event.pause) {
              this.lastReason = event.text;
              this.state.active = null;
            }
            changed = true;
          }
        }
      }
    } while (changed);
    for (const id of this.pendingCaps) {
      const stat = this.stat(id), key = `${id}:${stat.max}`;
      if (stat.value < stat.max || this.state.capHits.includes(key)) continue;
      this.state.capHits.push(key);
      const raisers = this.capRaisers(id).map(record => record.name ?? record.id);
      this.log("cap", `${this.record(id).name ?? id} has reached ${stat.value}/${stat.max}. ${raisers.length ? `A higher cap is possible through ${raisers.join(" or ")}.` : "Further ways to raise this cap have not been discovered."}`);
    }
    this.pendingCaps.clear();
  }

  private finishObjective(): void {
    const active = this.state.active;
    if (!active) return;
    const name = this.record(active.id).name ?? active.id;
    this.lastReason = `${name}: objective complete.`;
    this.log("completion", this.lastReason);
    this.state.active = null;
  }

  private pause(reason: string): void {
    this.state.active = null;
    this.lastReason = reason;
    this.log("pause", reason);
  }

  private log(kind: LogEntry["kind"], text: string): void {
    const id = (this.state.log.at(-1)?.id ?? 0) + 1;
    this.state.log.push({ id, kind, text, activitySeconds: this.state.activitySeconds });
    if (this.state.log.length > 160) this.state.log.splice(0, this.state.log.length - 160);
  }

  private createCheckpoint(label: string): void {
    const { bank, checkpoint: _checkpoint, ...world } = this.state;
    this.state.bank.spentSinceCheckpoint = 0;
    this.state.checkpoint = { world: clone(world), bankCap: bank.cap, label };
  }

  private creditBank(seconds: number): number {
    const amount = Math.max(0, Math.min(seconds, this.state.bank.cap - this.state.bank.seconds));
    this.state.bank.seconds += amount;
    return amount;
  }

  private requireSeconds(seconds: number): void {
    if (!Number.isFinite(seconds) || seconds < 0 || seconds > UNBOUNDED) throw new Error("Elapsed time must be a finite, nonnegative number of seconds.");
  }
}
