/** Content is declarative; expression strings are interpreted by expression.ts. */
export type Expression = string;
export type Changes = Record<string, number | Expression>;
export type RecordKind = "resource" | "family" | "task" | "site" | "arrangement" | "home" | "class" | "breakthrough" | "teaching" | "recipe" | "technique" | "purchase" | "flag" | "lead";

export interface Stat {
  value: number;
  max: number;
  exp: number;
  rate: number;
  reps: number;
  open: boolean;
  length: number;
  yield: number;
  ticks: number;
  started: boolean;
}

export interface NarrativeEvent {
  id: string;
  when: Expression;
  text: string;
  changes?: Changes;
  pause?: boolean;
}

export interface Breakthrough {
  title?: string;
  core: Expression;
  coreLabel?: string;
  pointers: { label: string; when: Expression }[];
  required: number;
}

export interface GameRecord {
  id: string;
  kind: RecordKind;
  name?: string;
  desc?: string;
  group?: string;
  tags?: string[];
  require?: Expression;
  need?: Expression;
  needtext?: string;
  initial?: Partial<Stat>;
  max?: number;
  runway?: number;
  buy?: Changes;
  cost?: Changes;
  length?: number | "continuous";
  /** Positive run amounts are resources consumed per activity second. */
  run?: Changes;
  effect?: Changes;
  result?: Changes;
  mod?: Changes;
  perLevel?: Changes;
  /** First start only, even when that activity is subsequently interrupted. */
  onStart?: Changes;
  /** Repetition thresholds; for continuous practice these are activity seconds. */
  at?: Record<string, Changes>;
  every?: Record<string, Changes>;
  disable?: string[];
  space?: number;
  train?: string;
  strain?: Changes;
  events?: NarrativeEvent[];
  breakthrough?: Breakthrough;
  raisers?: string[];
  pauseOnReveal?: boolean;
  pauseOnComplete?: boolean;
}

export interface Objective {
  kind: "repetitions" | "level" | "resource";
  id: string;
  /** Absolute total, not an additional amount. */
  target: number;
}

export interface ActiveTask {
  id: string;
  progress: number;
  objective: Objective;
}

export interface LogEntry {
  id: number;
  kind: "discovery" | "cap" | "completion" | "pause" | "purchase" | "retry";
  text: string;
  activitySeconds: number;
}

export interface Bank {
  seconds: number;
  cap: number;
  spentSinceCheckpoint: number;
}

/** Exact character/world snapshot. Bank balance and refund ledger live outside it. */
export interface WorldState {
  stats: Record<string, Stat>;
  active: ActiveTask | null;
  age: number;
  lifespan: number;
  activitySeconds: number;
  visibleIds: string[];
  disabledIds: string[];
  eventIds: string[];
  capHits: string[];
  log: LogEntry[];
  /** Sub-second wall time reserved toward the next 1-second activity tick. */
  wallRemainder: number;
}

export interface Checkpoint {
  world: WorldState;
  bankCap: number;
  label: string;
}

export interface GameState extends WorldState {
  bank: Bank;
  checkpoint: Checkpoint;
}

export interface Availability {
  ok: boolean;
  reason: string;
}

export interface AdvanceResult {
  activitySeconds: number;
  bankedSeconds: number;
  spentSeconds: number;
  reason?: string;
}
