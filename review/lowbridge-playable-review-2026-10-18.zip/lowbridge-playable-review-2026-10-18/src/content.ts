import shared from "./data/shared.json";
import opening from "./data/opening.json";
import type { GameRecord } from "./types";

/** The browser, route runner and validator all consume these same source records. */
export const records = [...shared, ...opening] as GameRecord[];
export const recordById = new Map(records.map((record) => [record.id, record]));

export const openingContext = {
  title: "Lowbridge",
  place: "Hayloft above Miller Wen’s barn",
  introduction:
    "The mill stream meets the ferry road here. Wen has sacks to move; Granny Shu has herbs to sort. Beyond the barns, the water runs through a broken channel toward the wilds.",
  bound: "Village to Foundation",
} as const;
