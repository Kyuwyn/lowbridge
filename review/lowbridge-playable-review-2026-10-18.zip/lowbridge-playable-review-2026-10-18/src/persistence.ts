import type { GameRecord, GameState, WorldState } from './types';
import { GameEngine } from './engine';

export const SAVE_FORMAT = 'lowbridge-save';
export const SAVE_VERSION = 1;
export const DATABASE_NAME = 'lowbridge-first-slice';

export interface SaveFile {
  format: typeof SAVE_FORMAT;
  version: typeof SAVE_VERSION;
  savedAt: number;
  state: GameState;
}

const fail = (message: string): never => { throw new Error(`Save could not be loaded: ${message}`); };
function object(value: unknown, label: string): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail(`${label} is missing or invalid.`);
  return value as Record<string, unknown>;
}
function number(value: unknown, label: string, maximum = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > maximum) fail(`${label} is not a valid number.`);
  return value as number;
}
function strings(value: unknown, label: string, known?: Set<string>): string[] {
  if (!Array.isArray(value) || value.length > 5000 || value.some(id => typeof id !== 'string' || id.length > 1000 || (known && !known.has(id)))) {
    fail(`${label} contains invalid entries.`);
  }
  return value as string[];
}

/** Reject invalid input before it can replace the live game or the current save. */
export function decodeSave(input: unknown, records: GameRecord[]): SaveFile {
  const raw = typeof input === 'string' ? JSON.parse(input) as unknown : input;
  const save = object(raw, 'Save');
  if (save.format !== SAVE_FORMAT) fail('this is not a Lowbridge save.');
  if (save.version !== SAVE_VERSION) fail('this save uses an unsupported version.');
  number(save.savedAt, 'Save time', 8.64e15);
  const known = new Set(records.map(record => record.id));
  const definitions = new Map(records.map(record => [record.id, record]));
  function world(input: unknown, label: string): WorldState {
    const value = object(input, label);
    const stats = object(value.stats, `${label} stats`);
    if (Object.keys(stats).length !== known.size || Object.keys(stats).some(id => !known.has(id))) fail(`${label} has unknown or missing records.`);
    for (const [id, item] of Object.entries(stats)) {
      const stat = object(item, `${id} stats`);
      for (const key of ['value', 'max', 'exp', 'rate', 'reps', 'length', 'yield', 'ticks']) number(stat[key], `${id}.${key}`);
      for (const key of ['open', 'started']) if (typeof stat[key] !== 'boolean') fail(`${id}.${key} is invalid.`);
      if (!Number.isInteger(stat.reps) || !Number.isInteger(stat.ticks)) fail(`${id} counters must be whole numbers.`);
      const kind = definitions.get(id)!.kind;
      if (typeof definitions.get(id)!.length === 'number' && (stat.length as number) < 1) fail(`${id} has an invalid activity duration.`);
      if ((kind === 'family' || kind === 'resource') && (stat.value as number) > (stat.max as number) + 1e-7) fail(`${id} exceeds its cap.`);
      if (kind === 'family' && (!Number.isInteger(stat.value) || (stat.exp as number) >= 60 * ((stat.value as number) + 1) + 1e-7)) fail(`${id} practice progress is invalid.`);
    }
    const age = number(value.age, `${label} age`);
    const lifespan = number(value.lifespan, `${label} lifespan`);
    if (age > lifespan + 1e-7) fail(`${label} age exceeds lifespan.`);
    number(value.activitySeconds, `${label} activity time`);
    if (number(value.wallRemainder, `${label} partial tick`, 1) >= 1) fail(`${label} partial tick is invalid.`);
    strings(value.visibleIds, `${label} visible records`, known);
    strings(value.disabledIds, `${label} closed records`, known);
    strings(value.eventIds, `${label} discoveries`);
    strings(value.capHits, `${label} cap notices`);
    if (!Array.isArray(value.log) || value.log.length > 5000) fail(`${label} journal is invalid.`);
    for (const entry of value.log as unknown[]) {
      const log = object(entry, 'Journal entry');
      number(log.id, 'Journal id');
      number(log.activitySeconds, 'Journal time');
      if (typeof log.text !== 'string' || log.text.length > 10000 || !['discovery', 'cap', 'completion', 'pause', 'purchase', 'retry'].includes(log.kind as string)) fail('journal entry is invalid.');
    }
    if (value.active !== null) {
      const active = object(value.active, `${label} activity`);
      const record = definitions.get(active.id as string);
      if (!record || record.length === undefined || record.length === 0) fail(`${label} activity is invalid.`);
      number(active.progress, 'Activity progress');
      const objective = object(active.objective, 'Objective');
      const target = number(objective.target, 'Objective target');
      if (!known.has(objective.id as string) || !['repetitions', 'level', 'resource'].includes(objective.kind as string)) fail('objective is invalid.');
      if (objective.kind !== 'resource' && !Number.isInteger(target)) fail('objective target must be a whole number.');
      if (objective.kind === 'level' && definitions.get(objective.id as string)?.kind !== 'family') fail('practice objective has no family.');
      if (objective.kind === 'resource' && definitions.get(objective.id as string)?.kind !== 'resource') fail('resource objective is invalid.');
      if (objective.kind === 'repetitions' && objective.id !== active.id) fail('repetition objective belongs to another activity.');
    }
    return value as unknown as WorldState;
  }
  const state = object(save.state, 'State');
  world(state, 'Current state');
  const bank = object(state.bank, 'Bank');
  const cap = number(bank.cap, 'Bank capacity');
  if (number(bank.seconds, 'Bank balance') > cap + 1e-7) fail('bank balance exceeds its capacity.');
  number(bank.spentSinceCheckpoint, 'Bank refund ledger');
  const checkpoint = object(state.checkpoint, 'Checkpoint');
  world(checkpoint.world, 'Checkpoint');
  number(checkpoint.bankCap, 'Checkpoint bank capacity');
  if (typeof checkpoint.label !== 'string' || checkpoint.label.length > 200) fail('checkpoint name is invalid.');
  const candidate = new GameEngine(records, state as unknown as GameState);
  for (const current of [candidate.state, candidate.state.checkpoint.world]) {
    if (!current.active) continue;
    const restored = new GameEngine(records, { ...current, bank: candidate.state.bank, checkpoint: candidate.state.checkpoint });
    const valid = restored.objectiveAvailability(current.active.id, current.active.objective, current.active.progress);
    if (!valid.ok) fail(valid.reason);
  }
  return structuredClone(save) as unknown as SaveFile;
}

export function makeSave(state: GameState, savedAt = Date.now()): SaveFile {
  return { format: SAVE_FORMAT, version: SAVE_VERSION, savedAt, state: structuredClone(state) };
}

export class SaveStore {
  private constructor(private db: IDBDatabase) {}

  static async open(): Promise<SaveStore> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, 1);
      request.onupgradeneeded = () => request.result.createObjectStore('saves');
      request.onerror = () => reject(request.error || new Error('Browser storage is unavailable.'));
      request.onblocked = () => reject(new Error('Another Lowbridge tab is blocking save storage. Close it and reload.'));
      request.onsuccess = () => {
        request.result.onversionchange = () => request.result.close();
        resolve(new SaveStore(request.result));
      };
    });
  }

  async load(records: GameRecord[]): Promise<{ save: SaveFile | null; recovered: boolean }> {
    const slots = await new Promise<unknown[]>((resolve, reject) => {
      const transaction = this.db.transaction('saves', 'readonly');
      const store = transaction.objectStore('saves');
      const current = store.get('current');
      const backup = store.get('backup');
      transaction.oncomplete = () => resolve([current.result, backup.result]);
      transaction.onabort = () => reject(transaction.error || new Error('Could not read save storage.'));
    });
    if (slots[0] === undefined && slots[1] === undefined) return { save: null, recovered: false };
    let lastError: unknown;
    for (let index = 0; index < slots.length; index++) {
      if (slots[index] === undefined) continue;
      try { return { save: decodeSave(slots[index], records), recovered: index === 1 }; }
      catch (error) { lastError = error; }
    }
    throw lastError || new Error('No readable Lowbridge save was found.');
  }

  /** Save and backup update together; resolve only after the transaction commits. */
  async write(save: SaveFile, records: GameRecord[]): Promise<void> {
    const checked = decodeSave(save, records);
    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction('saves', 'readwrite');
      const store = transaction.objectStore('saves');
      const previous = store.get('current');
      previous.onsuccess = () => {
        if (previous.result !== undefined) {
          try { store.put(decodeSave(previous.result, records), 'backup'); }
          catch { /* Preserve the valid backup if current storage is damaged. */ }
        }
        store.put(checked, 'current');
      };
      transaction.oncomplete = () => resolve();
      transaction.onabort = () => reject(transaction.error || new Error('The browser could not save progress.'));
    });
  }

  close() { this.db.close(); }
}
