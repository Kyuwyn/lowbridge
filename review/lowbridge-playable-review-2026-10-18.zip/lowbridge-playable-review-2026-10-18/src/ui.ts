import type { GameEngine } from "./engine";
import type { GameRecord, Objective } from "./types";
import { openingContext } from "./content";

export interface UICallbacks {
  beforeChange?(): void;
  onChange(): Promise<void> | void;
  onExport(): Promise<void> | void;
  onImport(file: File): Promise<void> | void;
  onRetry(): Promise<void> | void;
  onNewGame(): Promise<void> | void;
}

const groups = ["Work", "Practice", "Sites", "Home"] as const;
type Group = typeof groups[number];
const groupNotes: Record<Group, string> = {
  Work: "Wages, bundles, and village trade",
  Practice: "The surviving leaves and the missing turn",
  Sites: "Places beyond the barn",
  Home: "Shelter and arrangements",
};
const groupEmpty: Record<Group, string> = {
  Work: "There is no work here at present.",
  Practice: "No method has come into your hands yet.",
  Sites: "The stream leads out beyond the barns. Its current is still only water to you.",
  Home: "There are no arrangements here yet.",
};

/** Stroke-only glyph set, 24×24, currentColor. Keys: resource ids and lowercase group names. */
const GLYPH_PATHS: Record<string, string> = {
  coin: '<circle cx="12" cy="12" r="7.5"/><rect x="9.3" y="9.3" width="5.4" height="5.4"/>',
  herbs: '<path d="M12 20v-9"/><path d="M12 14c-3.2 0-5.2-2.2-5.2-5.4 3.2 0 5.2 2.2 5.2 5.4Z"/><path d="M12 11.4c0-3.2 2-5.4 5.2-5.4 0 3.2-2 5.4-5.2 5.4Z"/>',
  timber: '<rect x="3" y="10" width="15" height="6.5" rx="3.25"/><circle cx="14.5" cy="13.25" r="1.3"/>',
  stone: '<path d="M5.5 17.5 7 9.5l5.5-3 6 3.5-1 7.5-6.5 2Z"/>',
  qi: '<path d="M7.5 18c-2.2-2.2-2.2-4.3 0-6.5s2.2-4.3 0-6.5"/><path d="M12.5 18c-2.2-2.2-2.2-4.3 0-6.5s2.2-4.3 0-6.5"/><path d="M17.5 18c-2.2-2.2-2.2-4.3 0-6.5s2.2-4.3 0-6.5"/>',
  work: '<path d="M4 9.5h16V20H4Z"/><path d="M4 9.5 7 5h10l3 4.5"/><path d="M12 9.5V20"/>',
  practice: '<path d="M12 18.5c-4.2-1-7.2-4.2-7.2-8.3 3.3 0 6 2 7.2 5.2 1.2-3.2 3.9-5.2 7.2-5.2 0 4.1-3 7.3-7.2 8.3Z"/><path d="M12 18.5v2"/>',
  sites: '<path d="M3 18.5 9.5 8l4 6 3-4 4.5 8.5"/><path d="M3 21h18"/>',
  home: '<path d="M4 11.5 12 4.5l8 7"/><path d="M6.5 10v9h11v-9"/>',
};

function glyph(id: string): Element {
  const template = document.createElement("template");
  template.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${GLYPH_PATHS[id] ?? ""}</svg>`;
  return template.content.firstElementChild!;
}

function element<K extends keyof HTMLElementTagNameMap>(tag: K, className = "", text = ""): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

function setText(node: HTMLElement, text: string): void {
  if (node.textContent !== text) node.textContent = text;
}

function number(value: number): string {
  return Number.isInteger(value) ? String(value) : value.toFixed(value < 10 ? 1 : 0);
}

function duration(seconds: number): string {
  const whole = Math.max(0, Math.floor(seconds));
  if (whole < 60) return `${whole}s`;
  const hours = Math.floor(whole / 3600);
  const minutes = Math.floor((whole % 3600) / 60);
  const rest = whole % 60;
  if (hours) return `${hours}h ${minutes.toString().padStart(2, "0")}m`;
  return `${minutes}m ${rest.toString().padStart(2, "0")}s`;
}

function meter(className = ""): { root: HTMLDivElement; fill: HTMLDivElement; update(value: number, max: number): void } {
  const root = element("div", `meter ${className}`.trim());
  const fill = element("div", "meter-fill");
  root.setAttribute("aria-hidden", "true");
  root.append(fill);
  return { root, fill, update(value, max) { fill.style.width = `${max > 0 ? Math.min(100, Math.max(0, value / max * 100)) : 0}%`; } };
}

/** Builds each control once. render() patches text and state, preserving native focus and edits. */
export function createUI(initialEngine: GameEngine, callbacks: UICallbacks) {
  let engine = initialEngine;
  let selectedGroup: Group = "Work";
  let saveStatus = "Save ready";
  let latestAnnouncement = "";
  let settingsBusy = false;
  let disposed = false;
  const root = document.querySelector<HTMLElement>("#app");
  if (!root) throw new Error("Lowbridge needs an #app element.");
  root.innerHTML = `
    <a class="skip-link" href="#activities">Skip to activities</a>
    <div class="game-shell">
      <header class="masthead">
        <div class="brand"><svg class="brand-mark" width="30" height="30" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path d="M4 20c3.5-7.5 7.5-10.5 12-10.5S24.5 12.5 28 20" stroke="currentColor" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M7 24.5h18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" opacity=".45"/><path d="M11 17.5v4M21 17.5v4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" opacity=".3"/></svg><h1>Lowbridge</h1><p class="brand-note">Where the mill stream meets the ferry road</p></div>
        <div class="masthead-right"><p class="life-readout"><span>Age <strong data-ui="age"></strong></span><span>Lifespan <strong data-ui="lifespan"></strong></span></p><p class="save-status" data-ui="save-status" role="status"></p></div>
      </header>
      <details class="settings"><summary>Save &amp; settings</summary>
        <div class="settings-body">
          <button type="button" data-ui="export">Export save</button>
          <button type="button" data-ui="import">Import save</button>
          <button type="button" data-ui="retry">Retry checkpoint</button>
          <button type="button" class="quiet-button danger-button" data-ui="new-game">New game</button>
          <input type="file" accept=".json,application/json" data-ui="file" hidden />
          <p data-ui="checkpoint-note"></p>
          <div class="confirmation" data-ui="confirmation" hidden><p data-ui="confirmation-text"></p><button type="button" class="danger-button" data-ui="confirm">Confirm</button><button type="button" data-ui="cancel">Cancel</button></div>
          <p class="settings-feedback" data-ui="settings-feedback" role="status" hidden></p>
        </div>
      </details>
      <section class="bank-strip" aria-labelledby="bank-heading">
        <div class="bank-info"><div class="bank-heading"><h2 id="bank-heading">Time bank</h2><span class="bank-amount numeric" data-ui="bank-amount"></span></div><div data-ui="bank-meter"></div><div class="bank-chips" data-ui="bank-chips"></div><p class="bank-note">Unused time is kept here. Banked time advances the chosen objective.</p></div>
        <div class="bank-objective"><p class="objective-caption">Current objective</p><p class="objective-name" data-ui="objective-name"></p><p class="objective-progress" data-ui="objective-progress"></p></div>
        <div class="bank-actions"><button type="button" class="primary-button" data-ui="accelerate" data-action="accelerate">Accelerate objective</button><button type="button" class="quiet-button" data-ui="stop" data-action="stop">Pause activity</button></div>
      </section>
      <div class="game-grid">
        <aside class="left-column" aria-label="Character and resources">
          <section class="panel resources-panel"><div class="panel-heading"><h2>Resources</h2><span class="aside-note">held / capacity</span></div><div class="resource-list" data-ui="resources"></div></section>
          <section class="panel family-panel" data-ui="families-panel" hidden><div class="panel-heading"><h2>Method</h2><span class="aside-note">level / limit</span></div><div class="family-list" data-ui="families"></div></section>
          <section class="panel home-panel"><div class="panel-heading"><h2>Home</h2></div><div class="panel-body"><p class="home-name" data-ui="home-name"></p><p class="home-note">Arrangements occupy spans of floor and stay with you when you move.</p><p class="home-space" data-ui="home-space"></p></div></section>
        </aside>
        <main class="centre-column">
          <section class="panel scene"><p class="eyebrow" data-ui="stage">The village</p><h2 data-ui="scene-title"></h2><p data-ui="scene-description"></p>
            <details class="slip" data-ui="slip" hidden><summary>The Cracked Jade Slip · leaves 1, 2, 8</summary><blockquote><p><em>Lesser Breath-Gathering Method.</em> “Sit as water sits. Draw the breath past the throat and let it pool below the navel. Feel for what is not air.”</p><p>Leaf 8: “…when the pooled breath turns, do not follow it. Wait at the turning. The rest is…” The remaining characters are chipped away.</p></blockquote></details>
          </section>
          <section class="panel completion-panel" data-ui="completion" hidden><div class="panel-heading"><h2>Foundation</h2><span class="aside-note">A decision pause</span></div><div class="panel-body"><p>The pooled breath turns and returns. A method that once ended in a broken sentence has become your own.</p><p class="completion-note">The opening is complete. Your checkpoint is now Foundation. These are the leads beyond it; their journeys and class choices are not part of this playable opening.</p><ul class="lead-list" data-ui="leads"></ul></div></section>
          <section class="panel activity-panel" id="activities" tabindex="-1"><nav class="activity-nav" aria-label="Activity groups" data-ui="tabs"></nav><div data-ui="groups"></div></section>
          <section class="panel foundation-panel" data-ui="foundation" hidden><div class="panel-heading"><h2 data-ui="foundation-title">Lay the foundation</h2><span class="aside-note">First breakthrough</span></div><div class="panel-body"><p class="foundation-intro" data-ui="foundation-description"></p><p class="foundation-caption">The core</p><ul class="foundation-list" data-ui="foundation-core"></ul><p class="foundation-caption" data-ui="foundation-count"></p><ul class="foundation-list" data-ui="foundation-pointers"></ul><div class="foundation-footer"><p class="card-facts" data-ui="foundation-bill"></p><p class="card-requirement" data-ui="foundation-need"></p><button type="button" class="primary-button card-button" data-ui="foundation-start">Settle the foundation</button></div></div></section>
        </main>
        <aside class="right-column" aria-labelledby="journal-heading"><div class="journal-heading"><h2 id="journal-heading">The village journal</h2><p>Discoveries, limits, and the things people say.</p></div><ol class="journal-list" data-ui="journal"></ol><p class="empty-state journal-empty" data-ui="journal-empty">The mill wheel turns below the hayloft. The day is still unwritten.</p></aside>
      </div>
      <footer class="game-footer"><span>Lowbridge · Village to Foundation</span><span data-ui="activity-time"></span></footer>
      <p class="sr-only" role="status" aria-live="polite" aria-atomic="true" data-ui="announcement"></p>
    </div>`;

  function ui<T extends HTMLElement = HTMLElement>(key: string): T {
    const found = root!.querySelector<T>(`[data-ui="${key}"]`);
    if (!found) throw new Error(`Missing UI node: ${key}`);
    return found;
  }
  const bankMeter = meter();
  ui("bank-meter").append(bankMeter.root);
  setText(ui("scene-title"), openingContext.place);
  setText(ui("scene-description"), openingContext.introduction);

  function label(id: string): string { return engine.records.find((record) => record.id === id)?.name ?? id.replaceAll("_", " "); }
  function current(id: string): number { return engine.state.stats[id]?.value ?? 0; }
  function announce(message: string): void {
    if (message && message !== latestAnnouncement) { latestAnnouncement = message; setText(ui("announcement"), message); }
  }
  async function change(action: () => void): Promise<void> {
    try {
      callbacks.beforeChange?.();
      action();
      render();
      await callbacks.onChange();
    } catch (error) { showSettingsError(error); }
  }
  function showSettingsError(error: unknown): void {
    const feedback = ui("settings-feedback");
    feedback.hidden = false;
    setText(feedback, error instanceof Error ? error.message : String(error));
    root!.querySelector<HTMLDetailsElement>(".settings")!.open = true;
  }
  async function settingsAction(action: () => Promise<void> | void): Promise<void> {
    if (settingsBusy) return;
    settingsBusy = true;
    ui("settings-feedback").hidden = true;
    render();
    try { await action(); } catch (error) { showSettingsError(error); }
    finally { settingsBusy = false; render(); }
  }
  let pendingConfirmation: (() => Promise<void> | void) | null = null;
  let confirmationTrigger: HTMLElement | null = null;
  function confirmAction(message: string, action: () => Promise<void> | void): void {
    pendingConfirmation = action;
    confirmationTrigger = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setText(ui("confirmation-text"), message);
    ui("confirmation").hidden = false;
    ui<HTMLButtonElement>("cancel").focus();
  }
  ui("export").addEventListener("click", () => { void settingsAction(callbacks.onExport); });
  ui("import").addEventListener("click", () => ui<HTMLInputElement>("file").click());
  ui<HTMLInputElement>("file").addEventListener("change", (event) => {
    const input = event.currentTarget as HTMLInputElement;
    const file = input.files?.[0];
    input.value = "";
    if (file) void settingsAction(() => callbacks.onImport(file));
  });
  ui("retry").addEventListener("click", () => confirmAction(`Return to ${engine.state.checkpoint.label}? Progress since that checkpoint will be restored, and bank spent since it will be refunded within the restored capacity.`, callbacks.onRetry));
  ui("new-game").addEventListener("click", () => confirmAction("Begin again in the hayloft? This replaces the current save. An exported save can be imported later.", callbacks.onNewGame));
  ui("cancel").addEventListener("click", () => { pendingConfirmation = null; ui("confirmation").hidden = true; confirmationTrigger?.focus(); });
  ui("confirm").addEventListener("click", () => {
    const action = pendingConfirmation;
    pendingConfirmation = null;
    ui("confirmation").hidden = true;
    if (action) void settingsAction(action).then(() => confirmationTrigger?.focus());
  });
  ui("accelerate").addEventListener("click", () => { void change(() => { engine.accelerate(); }); });
  ui("stop").addEventListener("click", () => { void change(() => engine.stop()); });

  const resourceRows = engine.records.filter((record) => record.kind === "resource" && record.group === "Resources").map((record) => {
    const row = element("div", "resource-row");
    row.dataset.resource = record.id;
    const heading = element("div", "resource-heading");
    const name = element("span", "resource-name", record.name ?? record.id);
    name.title = record.desc ?? "";
    const amount = element("span", "resource-value");
    heading.append(glyph(record.id), name, amount);
    const bar = meter();
    const note = element("p", "resource-rate");
    row.append(heading, bar.root, note);
    ui("resources").append(row);
    const chip = element("span", "bank-chip");
    chip.title = record.name ?? record.id;
    const chipValue = element("span");
    chip.append(glyph(record.id), chipValue);
    ui("bank-chips").append(chip);
    return { record, row, amount, bar, note, chip, chipValue };
  });

  const familyRows = engine.records.filter((record) => record.kind === "family").map((record) => {
    const row = element("div", "family-row");
    row.dataset.family = record.id;
    const heading = element("div", "family-heading");
    const name = element("span", "family-name", record.name ?? record.id);
    name.title = record.desc ?? "";
    const amount = element("span", "family-value");
    heading.append(name, amount);
    const pips = element("div", "family-pips");
    pips.setAttribute("aria-hidden", "true");
    const exp = element("p", "family-exp");
    const raisers = element("details", "family-raisers");
    raisers.append(element("summary", "", "What raises this limit"));
    const raiserText = element("p");
    raisers.append(raiserText);
    row.append(heading, pips, exp, raisers);
    ui("families").append(row);
    return { record, row, amount, pips, exp, raiserText };
  });

  const groupViews = new Map<Group, { button: HTMLButtonElement; count: HTMLSpanElement; panel: HTMLDivElement; list: HTMLDivElement; empty: HTMLParagraphElement }>();
  for (const group of groups) {
    const button = element("button", "activity-tab", group);
    button.type = "button";
    button.prepend(glyph(group.toLowerCase()));
    button.setAttribute("aria-controls", `group-${group.toLowerCase()}`);
    const count = element("span", "tab-count");
    count.setAttribute("aria-hidden", "true");
    button.append(count);
    button.addEventListener("click", () => { selectedGroup = group; render(); });
    ui("tabs").append(button);
    const panel = element("div");
    panel.id = `group-${group.toLowerCase()}`;
    const title = element("div", "group-title");
    title.append(element("h2", "", group), element("p", "", groupNotes[group]));
    const list = element("div", "activity-list");
    const empty = element("p", "empty-state group-empty", groupEmpty[group]);
    panel.append(title, empty, list);
    ui("groups").append(panel);
    groupViews.set(group, { button, count, panel, list, empty });
  }

  function costText(record: GameRecord): string {
    const costs = { ...record.cost, ...record.buy };
    const parts = Object.entries(costs).map(([id, value]) => `${number(engine.value(value))} ${label(id).toLowerCase()}`);
    if (record.space) parts.push(`${record.space} ${record.space === 1 ? "span" : "spans"} of floor`);
    return parts.length ? `Cost: ${parts.join(" · ")}` : "";
  }
  function factsText(record: GameRecord): string {
    const parts: string[] = [];
    const stat = engine.stat(record.id);
    if (record.length === "continuous") {
      if (record.train) parts.push(`${label(record.train)} practice`);
      parts.push(`${number(stat.rate)}× practice rate`);
    } else if (typeof record.length === "number") {
      parts.push(`${duration(stat.length)} / completion`);
      for (const [path, value] of Object.entries(record.result ?? {})) {
        const [id, property] = path.split(".");
        if (property === "open" || id === "foundation") continue;
        const amount = engine.value(value) + (!property && record.kind === "task" ? stat.yield : 0);
        parts.push(`+${number(amount)} ${label(id)}${property === "exp" ? " experience" : ""}`);
      }
    }
    if (record.length) parts.push(`${number(stat.reps)} completed`);
    const cost = costText(record);
    if (cost) parts.push(cost);
    return parts.join(" · ");
  }

  function createCard(record: GameRecord) {
    const card = element("article", "activity-card");
    card.dataset.record = record.id;
    card.dataset.recordId = record.id;
    const top = element("div", "card-top");
    const heading = element("h3", "card-title", record.name ?? record.id);
    heading.id = `record-title-${record.id}`;
    const button = element("button", "card-button primary-button");
    button.type = "button";
    button.dataset.action = "start";
    top.append(heading, button);
    const description = element("p", "card-description", record.desc ?? "");
    const facts = element("p", "card-facts");
    const requirement = element("p", "card-requirement");
    requirement.id = `record-need-${record.id}`;
    button.setAttribute("aria-describedby", requirement.id);
    const state = element("p", "card-state");
    const progress = meter("card-progress");
    const editor = element("div", "objective-editor");
    const choiceLabel = element("label", "", "Objective");
    const choice = element("select");
    choice.dataset.objective = record.id;
    choice.setAttribute("aria-label", `Objective for ${record.name ?? record.id}`);
    choice.append(new Option(record.length === "continuous" ? "Next family level" : "Next completion", ""));
    const isRepeatable = Boolean(record.length) && record.max !== 1;
    if (isRepeatable && record.length !== "continuous") choice.append(new Option("Total completions", `repetitions:${record.id}`));
    const outputFamilies = new Set<string>();
    const outputResources = new Set<string>();
    if (record.train) outputFamilies.add(record.train);
    for (const changes of [record.result, record.effect, ...Object.values(record.every ?? {})]) {
      for (const path of Object.keys(changes ?? {})) {
        const [id, property] = path.split(".");
        const output = engine.records.find((candidate) => candidate.id === id);
        if (property === "exp" && output?.kind === "family") outputFamilies.add(id);
        if (!property && output?.kind === "resource" && output.group === "Resources") outputResources.add(id);
      }
    }
    if (isRepeatable) {
      for (const id of outputFamilies) choice.append(new Option(`${label(id)} level`, `level:${id}`));
      for (const id of outputResources) choice.append(new Option(`${label(id)} held`, `resource:${id}`));
    }
    choiceLabel.append(choice);
    const targetLabel = element("label", "", "Target");
    const target = element("input");
    target.dataset.target = record.id;
    target.type = "number";
    target.step = "1";
    target.min = "1";
    target.inputMode = "numeric";
    target.setAttribute("aria-label", `Target for ${record.name ?? record.id}`);
    targetLabel.append(target);
    targetLabel.hidden = true;
    choice.addEventListener("change", () => {
      targetLabel.hidden = !choice.value;
      if (choice.value) {
        const [kind, id] = choice.value.split(":");
        const stat = engine.stat(id!);
        target.value = String(Math.floor(kind === "repetitions" ? stat.reps : stat.value) + 1);
        target.setAttribute("aria-label", `${choice.selectedOptions[0]!.text} target for ${record.name ?? record.id}`);
      }
      updateCard();
    });
    editor.append(choiceLabel, targetLabel);
    editor.hidden = !isRepeatable;
    card.append(top, description, facts, requirement, state, progress.root, editor);
    button.addEventListener("click", () => {
      let objective: Objective | undefined;
      if (choice.value) {
        if (!target.reportValidity()) return;
        const [kind, id] = choice.value.split(":");
        objective = { kind: kind as Objective["kind"], id: id!, target: Number(target.value) };
      }
      void change(() => {
        const result = engine.start(record.id, objective);
        if (!result.ok) announce(result.reason);
      });
    });
    function updateCard(): void {
      const visible = engine.visible(record.id) && !engine.state.disabledIds.includes(record.id);
      card.hidden = !visible;
      if (!visible) return;
      const stat = engine.stat(record.id);
      const active = engine.state.active?.id === record.id;
      const owned = record.max === 1 && stat.value >= 1;
      const availability = engine.availability(record.id);
      card.classList.toggle("is-active", active);
      button.disabled = active || !availability.ok;
      const verb = record.length ? "Begin" : record.kind === "home" ? "Move in" : record.kind === "arrangement" ? "Install" : "Acquire";
      setText(button, active ? "Active" : owned ? (record.length ? "Complete" : record.kind === "home" ? "Home" : "Acquired") : verb);
      button.setAttribute("aria-label", `${active ? "Active:" : owned ? "Completed:" : verb} ${record.name ?? record.id}`);
      setText(facts, factsText(record));
      facts.hidden = !facts.textContent;
      requirement.hidden = active || owned || availability.ok;
      setText(requirement, availability.reason || record.needtext || "");
      state.hidden = !active;
      progress.root.hidden = !active;
      if (active) {
        const activeState = engine.state.active!;
        if (record.length === "continuous" && record.train) {
          const family = engine.stat(record.train);
          setText(state, `${number(family.exp)} / ${60 * (family.value + 1)} experience toward ${label(record.train)} ${family.value + 1}`);
          progress.update(family.exp, 60 * (family.value + 1));
        } else {
          setText(state, `${duration(activeState.progress)} / ${duration(stat.length)} this completion`);
          progress.update(activeState.progress, stat.length);
        }
      }
      choice.disabled = active;
      target.disabled = active;
      if (choice.value) {
        const [kind, id] = choice.value.split(":");
        const targetStat = engine.stat(id!);
        target.min = String(Math.floor(kind === "repetitions" ? targetStat.reps : targetStat.value) + 1);
        if (kind === "repetitions") target.removeAttribute("max");
        else target.max = String(targetStat.max);
      }
    }
    return { record, card, update: updateCard };
  }

  const cards = engine.records.filter((record) => groups.includes(record.group as Group) && !["resource", "family", "breakthrough"].includes(record.kind)).map((record) => {
    const card = createCard(record);
    groupViews.get(record.group as Group)!.list.append(card.card);
    return card;
  });
  const purchaseSection = element("section");
  const purchaseHeading = element("div", "purchase-heading");
  purchaseHeading.append(element("h3", "", "Village trade"), element("p", "", "Tools, small provisions, and what Granny Shu keeps behind the stall."));
  purchaseSection.append(purchaseHeading);
  const purchaseCards = engine.records.filter((record) => record.group === "Purchases").map((record) => {
    const card = createCard(record);
    purchaseSection.append(card.card);
    return card;
  });
  groupViews.get("Work")!.list.append(purchaseSection);

  function checklistItem(text: string) {
    const row = element("li");
    const check = element("span", "foundation-check");
    check.setAttribute("aria-hidden", "true");
    const wording = element("span", "", text);
    row.append(check, wording);
    return { row, update(ok: boolean) { row.classList.toggle("complete", ok); setText(check, ok ? "✓" : "○"); row.setAttribute("aria-label", `${ok ? "Met" : "Unmet"}: ${text}`); } };
  }
  const breakthroughRecord = engine.records.find((record) => record.breakthrough);
  const breakthrough = breakthroughRecord?.breakthrough;
  const coreItem = checklistItem(breakthrough?.coreLabel ?? "The reconstructed method");
  ui("foundation-core").append(coreItem.row);
  const pointerItems = (breakthrough?.pointers ?? []).map((pointer) => {
    const item = checklistItem(pointer.label);
    ui("foundation-pointers").append(item.row);
    return { pointer, item };
  });
  if (breakthroughRecord) {
    setText(ui("foundation-title"), breakthrough?.title ?? breakthroughRecord.name ?? "Lay the foundation");
    setText(ui("foundation-description"), breakthroughRecord.desc ?? "");
    ui("foundation").dataset.recordId = breakthroughRecord.id;
    ui("foundation-start").dataset.action = "start";
    ui("foundation-start").addEventListener("click", () => { void change(() => { engine.start(breakthroughRecord.id); }); });
  }
  const leadItems = engine.records.filter((record) => record.kind === "lead").map((record) => {
    const item = element("li");
    item.append(element("h3", "", record.name ?? record.id));
    const description = element("p");
    item.append(description);
    ui("leads").append(item);
    return { record, item, description };
  });
  const logNodes = new Map<number, HTMLLIElement>();

  function objectiveText(objective: Objective): string {
    if (objective.kind === "repetitions") return `${number(objective.target)} total ${objective.target === 1 ? "completion" : "completions"}`;
    if (objective.kind === "level") return `${label(objective.id)} level ${number(objective.target)}`;
    return `${number(objective.target)} ${label(objective.id).toLowerCase()} held`;
  }

  function render(status?: string): void {
    if (disposed) return;
    if (status !== undefined) saveStatus = status;
    const state = engine.state;
    setText(ui("save-status"), saveStatus);
    setText(ui("age"), `${state.age.toFixed(2)} years`);
    setText(ui("lifespan"), `${number(state.lifespan)} years`);
    setText(ui("bank-amount"), `${duration(state.bank.seconds)} / ${duration(state.bank.cap)}`);
    bankMeter.update(state.bank.seconds, state.bank.cap);
    setText(ui("activity-time"), `${duration(state.activitySeconds)} of activity`);
    setText(ui("checkpoint-note"), `Checkpoint: ${state.checkpoint.label}. Time away advances the saved objective until it stops; the remainder goes to the bank. Paused time does not age you.`);
    const active = state.active;
    setText(ui("objective-name"), active ? label(active.id) : "At rest");
    setText(ui("objective-progress"), active ? `Until ${objectiveText(active.objective)}` : state.age >= state.lifespan ? "This life has reached its limit. The checkpoint remains." : "The bank fills while no activity is chosen.");
    ui<HTMLButtonElement>("accelerate").disabled = !active || state.bank.seconds < 1;
    ui<HTMLButtonElement>("accelerate").title = !active ? "An activity needs a chosen objective." : state.bank.seconds < 1 ? "The time bank is empty." : `Spend banked time toward ${objectiveText(active.objective)}.`;
    ui<HTMLButtonElement>("stop").disabled = !active;
    ui("slip").hidden = current("jade_slip") === 0;
    const foundationReached = current("foundation") > 0;
    setText(ui("stage"), foundationReached ? "Foundation · the first threshold" : "The village");
    ui("completion").hidden = !foundationReached;
    for (const id of ["export", "import", "retry", "new-game", "confirm"]) ui<HTMLButtonElement>(id).disabled = settingsBusy;

    for (const view of resourceRows) {
      const stat = engine.stat(view.record.id);
      view.row.hidden = !engine.visible(view.record.id);
      view.chip.hidden = view.row.hidden;
      setText(view.chipValue, number(stat.value));
      setText(view.amount, `${number(stat.value)} / ${number(stat.max)}`);
      view.bar.update(stat.value, stat.max);
      view.row.classList.toggle("at-cap", stat.value >= stat.max);
      const raisers = stat.value >= stat.max ? engine.capRaisers(view.record.id).map((record) => record.name ?? record.id) : [];
      setText(view.note, stat.value >= stat.max ? raisers.length ? `Capacity reached · ${raisers.join("; ")}` : "Capacity reached" : stat.rate > 0 ? `+${number(stat.rate)} / second` : "");
      view.note.hidden = !view.note.textContent;
    }
    let visibleFamilies = 0;
    for (const view of familyRows) {
      const stat = engine.stat(view.record.id);
      const visible = engine.visible(view.record.id);
      view.row.hidden = !visible;
      if (!visible) continue;
      visibleFamilies++;
      setText(view.amount, `${number(stat.value)} / ${number(stat.max)}`);
      while (view.pips.children.length < Math.floor(stat.max)) view.pips.append(element("span", "family-pip"));
      while (view.pips.children.length > Math.floor(stat.max)) view.pips.lastElementChild!.remove();
      Array.from(view.pips.children).forEach((pip, index) => pip.classList.toggle("filled", index < stat.value));
      setText(view.exp, !stat.open ? view.record.needtext ?? "The method has not opened." : stat.value >= stat.max ? "This runway is full." : `${number(stat.exp)} / ${60 * (stat.value + 1)} experience to level ${stat.value + 1}`);
      const raisers = engine.capRaisers(view.record.id).map((record) => record.name ?? record.id);
      setText(view.raiserText, raisers.length ? raisers.join("; ") : "No source for a higher limit is known yet.");
    }
    ui("families-panel").hidden = visibleFamilies === 0;
    const home = engine.records.find((record) => record.kind === "home" && current(record.id) > 0 && !state.disabledIds.includes(record.id));
    setText(ui("home-name"), home?.name ?? openingContext.place);
    const homeSpace = engine.state.stats.home_space;
    setText(ui("home-space"), homeSpace ? `${number(homeSpace.value)} / ${number(homeSpace.max)} spans occupied` : "");

    for (const card of [...cards, ...purchaseCards]) card.update();
    purchaseSection.hidden = !purchaseCards.some((card) => !card.card.hidden);
    for (const [group, view] of groupViews) {
      const count = cards.filter((card) => card.record.group === group && !card.card.hidden).length;
      setText(view.count, String(count));
      view.button.setAttribute("aria-pressed", String(group === selectedGroup));
      view.panel.hidden = group !== selectedGroup;
      view.empty.hidden = count > 0;
    }
    ui("foundation").hidden = !breakthroughRecord || !engine.visible(breakthroughRecord.id) || foundationReached;
    if (breakthroughRecord && breakthrough && !foundationReached) {
      coreItem.update(engine.condition(breakthrough.core));
      let met = 0;
      for (const { pointer, item } of pointerItems) { const ok = engine.condition(pointer.when); if (ok) met++; item.update(ok); }
      setText(ui("foundation-count"), `Supporting signs · ${met} of ${breakthrough.pointers.length} present · ${breakthrough.required} needed`);
      const available = engine.availability(breakthroughRecord.id);
      const settling = active?.id === breakthroughRecord.id;
      setText(ui("foundation-bill"), `${costText(breakthroughRecord)} · full qi · ${duration(engine.stat(breakthroughRecord.id).length)}`);
      setText(ui("foundation-need"), available.reason || breakthroughRecord.needtext || "");
      ui("foundation-need").hidden = available.ok || settling;
      const button = ui<HTMLButtonElement>("foundation-start");
      button.disabled = !available.ok || settling;
      setText(button, settling ? `Settling · ${duration(active.progress)} / ${duration(engine.stat(breakthroughRecord.id).length)}` : "Settle the foundation");
    }
    for (const { record, item, description } of leadItems) {
      item.hidden = !engine.visible(record.id);
      setText(description, `${record.desc ?? ""}${record.need && !engine.condition(record.need) ? ` ${record.needtext ?? ""}` : ""}`);
    }

    const journal = ui("journal");
    const entries = state.log.slice(-30).reverse();
    const keep = new Set(entries.map((entry) => entry.id));
    for (const [id, node] of logNodes) if (!keep.has(id)) { node.remove(); logNodes.delete(id); }
    entries.forEach((entry, index) => {
      let node = logNodes.get(entry.id);
      if (!node) {
        node = element("li", "journal-entry");
        const meta = element("div", "journal-meta");
        meta.append(element("span"), element("span", "journal-time"));
        node.append(meta, element("p", "journal-text"));
        logNodes.set(entry.id, node);
      }
      node.dataset.kind = entry.kind;
      const meta = node.firstElementChild!;
      setText(meta.firstElementChild as HTMLElement, entry.kind === "cap" ? "A limit reached" : entry.kind);
      setText(meta.lastElementChild as HTMLElement, duration(entry.activitySeconds));
      setText(node.lastElementChild as HTMLElement, entry.text);
      if (journal.children[index] !== node) journal.insertBefore(node, journal.children[index] ?? null);
    });
    ui("journal-empty").hidden = entries.length > 0;
    const lastMeaningful = [...state.log].reverse().find((entry) => entry.kind !== "completion");
    if (lastMeaningful) announce(lastMeaningful.text);
  }

  render();
  return {
    render,
    setEngine(next: GameEngine) { engine = next; render(); },
    destroy() { disposed = true; root.replaceChildren(); },
  };
}
