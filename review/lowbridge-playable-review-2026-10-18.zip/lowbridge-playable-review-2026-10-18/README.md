# Lowbridge

A browser cultivation incremental: an ordinary life in a mill village, an incomplete jade slip, and two ways to reconstruct its missing method. The first playable ends at Foundation. Text, capped resources, short practice runways, discoveries and a bank of unused time.

## Run locally

Requires Bun 1.4.x (developed with 1.4.0). The player bundle has no runtime dependencies.

```sh
bun install --frozen-lockfile
bun run dev
```

Open [Lowbridge on localhost](http://127.0.0.1:4173). The server builds on startup; restart it after source changes. To use another port: `PORT=4174 bun run dev`.

```sh
bun run typecheck
bun test
bun run validate
bun run validate:design
bun run build
bun run smoke
```

Browser smoke uses Playwright's Chromium (`bunx playwright install chromium` if the matching browser is not already present). It runs in isolated browser contexts and never uses a player's saved profile. The smoke server binds an available local port and shuts down when done.

## Playing and saving

Choose an objective for one activity. An objective, a new discovery, or a cap can pause it. Unused real time goes into the bank; acceleration spends that bank on the current objective and preserves ordinary age costs. Returning to the game resumes the saved objective only as far as its next stop, then banks the remainder.

The journal names known ways to raise caps. Visible unavailable actions explain their missing requirements. Foundation needs the reconstructed method, three supporting preparations, ten herbs and a full qi reservoir. Channel and hollow discoveries remain distinct; visiting one does not forbid the other.

Progress saves in this browser's IndexedDB. A second tab cannot run the same journey concurrently. **Export** in the save controls creates a portable JSON copy; **Import** resumes that snapshot without adding time since its export. Retry returns to the latest breakthrough checkpoint, retaining accrued bank and refunding bank spent since that checkpoint. A new journey replaces the current one after confirmation.

Time away is settled from the saved wall-clock time; an open visit uses a monotonic clock, so system clock corrections do not freeze progress or count time twice. Browser and operating-system suspend behavior can affect an open visit; closing the tab gives the clearest away-time boundary.

## Source of truth and scope

- [Design v2](design/DESIGN-PLAN-2026-10-18.md), including its implementation clarifications in §0.
- [Implementation plan](design/IMPLEMENTATION-PLAN-2026-10-18.md).
- [Playtest sheet](playtest/PLAYTEST-SHEET.md).
- [Measured report](playtest/SMOKE-REPORT.md).

There are no playable classes, combat, waystation, or B2 modules in this slice. The leads after Foundation show where the next slice begins. The Python design validators remain alongside the TypeScript validator that runs real content and engine behavior.

Inspired by [Arcanum: Theory of Magic](https://mathiashjelm.gitlab.io/arcanum/); this is a clean TypeScript implementation, not a fork of its runtime. The pinned primary-source study is retained in `research/`. The frozen review package is preserved unchanged.
