import { records as sourceRecords } from "../src/content";
import { GameEngine } from "../src/engine";
import type { GameRecord, GameState, LogEntry, Objective } from "../src/types";

/** These priorities are the two preserved Python preferences, with foundation → settling. */
export const ROUTES = {
  "channel-only": {
    prefer: ["settling", "coin_pouch", "jade_slip", "fragment_notes", "breath_gathering", "field_kit", "channel_observe",
      "clear_channel", "channel_arrangement", "channel_exercise", "cut_timber", "herb_rack", "fernhollow_observe"],
    avoid: ["sit_fernhollow", "steady_attention", "practice_mat", "lean_to", "shu_reading", "strongbox"],
  },
  "hollow-only": {
    prefer: ["settling", "coin_pouch", "jade_slip", "breath_gathering", "fragment_notes", "fernhollow_observe", "sit_fernhollow",
      "steady_attention", "practice_mat", "shu_reading", "channel_observe"],
    avoid: ["clear_channel", "channel_arrangement", "channel_exercise", "field_kit", "cut_timber", "herb_rack", "lean_to", "strongbox"],
  },
} as const;

export type OpeningRoute = keyof typeof ROUTES;
export interface RoutePreferences { prefer: readonly string[]; avoid: readonly string[] }
export interface RouteResult {
  name: string;
  success: boolean;
  reason: string;
  activitySeconds: number;
  foundationSeconds: number | null;
  actions: { id: string; at: number; elapsed: number; objective: Objective; unlocks: string[] }[];
  unlocks: { id: string; at: number }[];
  reached: string[];
  completed: string[];
  caps: Record<string, number>;
  repetitions: Record<string, number>;
  levels: Record<string, number>;
  capLog: LogEntry[];
  unknownRaiserLog: LogEntry[];
  log: LogEntry[];
  state: GameState;
}

function objectiveFor(engine: GameEngine, record: GameRecord): Objective {
  if (record.length === "continuous" && record.train) {
    const family = engine.stat(record.train);
    if (family.value < family.max) return { kind: "level", id: record.train, target: family.value + 1 };
    // At the Qi Sense wall the same breath method can finish filling the reservoir.
    if (record.id === "breath_gathering") return { kind: "resource", id: "qi", target: engine.stat("qi").max };
  }
  return { kind: "repetitions", id: record.id, target: engine.stat(record.id).reps + 1 };
}

function productive(engine: GameEngine, record: GameRecord): boolean {
  if (record.kind === "resource" || record.kind === "family" || record.kind === "flag" || record.kind === "lead") return false;
  if (record.max === 1 || record.kind === "breakthrough" || record.length === "continuous") return true;
  if (record.id === "sit_fernhollow") return engine.stat("qi_sense").value < engine.stat("qi_sense").max || engine.stat(record.id).reps < 3;
  return Object.keys(record.result ?? {}).some(path => {
    const [id, field] = path.split(".");
    const stat = engine.stat(id!);
    return field === "exp" ? stat.value < stat.max : field !== undefined || stat.value < stat.max;
  });
}

function preference(engine: GameEngine, id: string, preferences: RoutePreferences): number {
  if (preferences.avoid.includes(id)) return 999;
  if (id === "sort_herbs") return engine.stat(id).reps < 3 || (engine.stat("herbs").value < 10 && engine.stat("qi_sense").value < 1) ? 799 : 802;
  if (id === "mill_work") return 800;
  if (id === "gather_herbs") return engine.stat("herbs").value < 10 ? 798 : 999;
  const index = preferences.prefer.indexOf(id);
  return index < 0 ? 500 : index;
}

export interface RouteOptions {
  records?: GameRecord[];
  preferences?: RoutePreferences;
  maxSeconds?: number;
  maxActions?: number;
  afterFoundation?: readonly string[];
  beforeFoundation?: readonly string[];
  prelude?: readonly string[];
}

/** Real one-second engine ticks; there is no duplicated reward or leveling model here. */
export function runRoute(name: string, options: RouteOptions = {}): RouteResult {
  const records = options.records ?? sourceRecords;
  const preferences = options.preferences ?? ROUTES[name as OpeningRoute];
  if (!preferences) throw new Error(`No preferences for route ${name}`);
  const engine = new GameEngine(records);
  const actions: RouteResult["actions"] = [];
  const unlocks: RouteResult["unlocks"] = [];
  const seen = new Set<string>();
  const reached = new Set<string>();
  const log = new Map<number, LogEntry>();
  const maxSeconds = options.maxSeconds ?? 7200;
  let foundationSeconds: number | null = null;
  let reason = "No productive available action";
  const observe = () => {
    for (const entry of engine.state.log) log.set(entry.id, { ...entry });
    for (const record of records) {
      if (engine.visible(record.id) && !seen.has(record.id)) {
        seen.add(record.id);
        unlocks.push({ id: record.id, at: engine.state.activitySeconds });
      }
      if (!engine.visible(record.id)) continue;
      const stat = engine.stat(record.id);
      if (record.kind === "family" ? stat.open : record.kind === "lead"
        ? engine.condition(record.need)
        : record.kind === "resource" || record.kind === "flag" || stat.reps > 0 || stat.value > 0) reached.add(record.id);
    }
    if (foundationSeconds === null && engine.stat("foundation").value > 0) foundationSeconds = engine.state.activitySeconds;
  };
  observe();
  let preludeIndex = 0;
  for (let count = 0; count < (options.maxActions ?? 1200); count++) {
    const founded = foundationSeconds !== null;
    const after = options.afterFoundation?.find(id => engine.stat(id).reps < 1);
    if (founded && !after) { reason = "Foundation reached"; break; }
    let selected: GameRecord | undefined;
    if (preludeIndex < (options.prelude?.length ?? 0)) {
      const id = options.prelude![preludeIndex]!;
      if (!engine.availability(id).ok) { reason = `Prelude ${id}: ${engine.availability(id).reason}`; break; }
      selected = engine.record(id);
      preludeIndex++;
    } else if (founded && after && engine.availability(after).ok) selected = engine.record(after);
    else selected = records
      .filter(record => productive(engine, record) && engine.availability(record.id).ok && preference(engine, record.id, preferences) < 900)
      .filter(record => record.id !== "settling" || (options.beforeFoundation ?? []).every(id => engine.stat(id).reps > 0))
      .sort((a, b) => preference(engine, a.id, preferences) - preference(engine, b.id, preferences))[0];
    if (!selected) break;
    const objective = objectiveFor(engine, selected);
    const action = { id: selected.id, at: engine.state.activitySeconds, elapsed: 0, objective, unlocks: [] as string[] };
    const priorUnlockCount = unlocks.length;
    actions.push(action);
    engine.start(selected.id, objective);
    observe();
    while (engine.state.active) {
      engine.advance(1);
      observe();
      if (engine.state.activitySeconds >= maxSeconds) { reason = `Activity budget ${maxSeconds}s exceeded`; break; }
    }
    action.elapsed = engine.state.activitySeconds - action.at;
    action.unlocks = unlocks.slice(priorUnlockCount).map(item => item.id);
    if (engine.state.activitySeconds >= maxSeconds) break;
    if (count === (options.maxActions ?? 1200) - 1) reason = "Action budget exceeded";
  }
  observe();
  const fullLog = [...log.values()];
  const capLog = fullLog.filter(entry => entry.kind === "cap");
  return {
    name, success: foundationSeconds !== null, reason,
    activitySeconds: engine.state.activitySeconds, foundationSeconds, actions, unlocks,
    reached: [...reached],
    completed: records.filter(record => engine.stat(record.id).reps > 0 || engine.stat(record.id).value > 0).map(record => record.id),
    caps: Object.fromEntries(records.filter(record => record.kind === "family" || record.kind === "resource").map(record => [record.id, engine.stat(record.id).max])),
    repetitions: Object.fromEntries(records.filter(record => engine.stat(record.id).reps > 0).map(record => [record.id, engine.stat(record.id).reps])),
    levels: Object.fromEntries(records.filter(record => record.kind === "family").map(record => [record.id, engine.stat(record.id).value])),
    capLog, unknownRaiserLog: capLog.filter(entry => /unknown|unseen|no visible|not yet|not been discovered|undiscovered|elsewhere/i.test(entry.text)), log: fullLog,
    state: structuredClone(engine.state),
  };
}

/** Separate furniture choices matter: the four-span Lean-to cannot hold all five spans. */
export function runCoverageBranches(records: GameRecord[] = sourceRecords): RouteResult[] {
  const homeBase = ["coin_pouch", "jade_slip", "fragment_notes", "breath_gathering", "field_kit", "cut_timber", "lean_to", "strongbox"];
  return [
    runRoute("furnished-hollow", {
      records, maxSeconds: 18000,
      preferences: { prefer: [...homeBase, "practice_mat", "herb_rack", "shu_reading", "channel_observe", "clear_channel", "fernhollow_observe", "sit_fernhollow", "steady_attention", "settling"], avoid: ["channel_arrangement", "channel_exercise"] },
      beforeFoundation: ["practice_mat", "herb_rack", "lean_to", "strongbox"],
      prelude: ["mill_work", "mill_work", "mill_work", "practice_mat"],
      afterFoundation: ["ferry_hauling"],
    }),
    runRoute("stones-and-storage", {
      records, maxSeconds: 18000,
      preferences: { prefer: [...homeBase, "herb_rack", "shu_reading", "channel_observe", "clear_channel", "channel_arrangement", "channel_exercise", "fernhollow_observe", "settling"], avoid: ["practice_mat", "sit_fernhollow", "steady_attention"] },
      beforeFoundation: ["herb_rack", "lean_to", "strongbox", "channel_arrangement"],
      afterFoundation: ["ferry_hauling"],
    }),
  ];
}

export function compactRoute(result: RouteResult) {
  const { state, actions, ...report } = result;
  return { ...report, actionCount: actions.length, bank: state.bank, age: state.age };
}

if (import.meta.main) {
  const results = (Object.keys(ROUTES) as OpeningRoute[]).map(name => runRoute(name));
  if (process.argv.includes("--json")) console.log(JSON.stringify(results.map(compactRoute), null, 2));
  else for (const result of results) {
    console.log(`${result.name}: Foundation ${result.success ? "YES" : "NO"}; ${(result.activitySeconds / 60).toFixed(2)} active min; ${result.reason}`);
    console.log(`  ${result.unlocks.map(item => `${(item.at / 60).toFixed(2)}m ${item.id}`).join(" → ")}`);
    console.log(`  ${result.unknownRaiserLog.length} cap lines without a known visible raiser`);
  }
  if (results.some(result => !result.success || (result.foundationSeconds ?? Infinity) > 2700)) process.exitCode = 1;
}
