import { records as sourceRecords } from "../src/content";
import { GameEngine } from "../src/engine";
import { evaluateCondition, expressionReferences } from "../src/expression";
import type { Changes, GameRecord } from "../src/types";
import { compactRoute, ROUTES, runCoverageBranches, runRoute, type OpeningRoute, type RouteResult } from "./routes";

export interface ValidationReport {
  ok: boolean;
  errors: string[];
  routes: RouteResult[];
  coverageBranches: RouteResult[];
  recordCount: number;
  reachedCount: number;
  missing: string[];
}

const statFields = new Set(["value", "max", "exp", "rate", "reps", "open", "length", "yield", "ticks", "started"]);
const passiveKinds = new Set(["resource", "family", "flag", "lead"]);

function expressions(record: GameRecord): string[] {
  const result = [record.require, record.need, record.breakthrough?.core, ...record.breakthrough?.pointers.map(pointer => pointer.when) ?? [], ...record.events?.map(event => event.when) ?? []];
  const changes = [record.buy, record.cost, record.run, record.effect, record.result, record.mod, record.perLevel, record.onStart,
    ...Object.values(record.at ?? {}), ...Object.values(record.every ?? {}), ...record.events?.map(event => event.changes) ?? []];
  for (const map of changes) for (const value of Object.values(map ?? {})) if (typeof value === "string") result.push(value);
  return result.filter((value): value is string => typeof value === "string");
}

function changeMaps(record: GameRecord): (Changes | undefined)[] {
  return [record.buy, record.cost, record.run, record.effect, record.result, record.mod, record.perLevel, record.onStart, record.strain,
    ...Object.values(record.at ?? {}), ...Object.values(record.every ?? {}), ...record.events?.map(event => event.changes) ?? []];
}

/** Grammar and dependency checks use the very same parser as live actions. */
export function validateGrammar(records: GameRecord[]): string[] {
  const errors: string[] = [];
  const ids = new Set<string>();
  const events = new Set<string>();
  for (const record of records) {
    if (ids.has(record.id)) errors.push(`Duplicate record ${record.id}`);
    ids.add(record.id);
  }
  const checkPath = (path: string, record: GameRecord) => {
    if (["age", "lifespan", "bank", "bank.max", "bank.seconds"].includes(path)) return;
    const [id, field = "value", extra] = path.replace(/^g\./, "").split(".");
    if (!id || !ids.has(id)) errors.push(`${record.id}: unknown record path ${path}`);
    if (extra || !statFields.has(field)) errors.push(`${record.id}: unsupported field in ${path}`);
  };
  for (const record of records) {
    if (!/^[a-z][a-z0-9_]*$/.test(record.id)) errors.push(`Invalid record id ${record.id}`);
    for (const expression of expressions(record)) {
      try { for (const path of expressionReferences(expression)) checkPath(path, record); }
      catch (error) { errors.push(`${record.id}: invalid expression ${JSON.stringify(expression)}: ${String(error)}`); }
    }
    for (const changes of changeMaps(record)) for (const [path, value] of Object.entries(changes ?? {})) {
      checkPath(path, record);
      if (typeof value === "number" && !Number.isFinite(value)) errors.push(`${record.id}: non-finite change at ${path}`);
    }
    for (const initial of Object.values(record.initial ?? {})) if (typeof initial === "number" && !Number.isFinite(initial)) errors.push(`${record.id}: non-finite initial state`);
    for (const target of [...record.disable ?? [], ...record.raisers ?? [], ...record.train ? [record.train] : []]) if (!ids.has(target)) errors.push(`${record.id}: missing referenced record ${target}`);
    for (const event of record.events ?? []) {
      if (events.has(event.id)) errors.push(`Duplicate narrative event ${event.id}`);
      events.add(event.id);
    }
    if (typeof record.length === "number" && (record.length <= 0 || record.length > 7200)) errors.push(`${record.id}: ordinary task duration must be within 1–7200 seconds`);
    if (record.kind === "breakthrough" && !record.breakthrough) errors.push(`${record.id}: breakthrough has no mandatory core metadata`);
    if (record.breakthrough && (record.breakthrough.required < 0 || record.breakthrough.required > record.breakthrough.pointers.length)) errors.push(`${record.id}: invalid supporting pointer count`);
    if (passiveKinds.has(record.kind)) continue;
    // A count/level of one's own record cannot be the key needed for its first start.
    for (const gate of [record.require, record.need]) {
      if (!gate) continue;
      try {
        const own = expressionReferences(gate).some(path => path === `g.${record.id}` || path.startsWith(`g.${record.id}.`));
        if (own && !evaluateCondition(gate, path => {
          const [id, field] = path.replace(/^g\./, "").split(".");
          if (id === record.id) return field === "max" ? 1000001 : 0;
          return field === "max" ? 1000001 : 1000000;
        })) errors.push(`${record.id}: self-key prevents its first use (${gate})`);
      } catch { /* The parser error above contains the useful detail. */ }
    }
  }
  return [...new Set(errors)];
}

/** Adversarial gate states only: these are never counted as reachability evidence. */
export function validateMandatoryCores(records: GameRecord[]): string[] {
  const errors: string[] = [];
  const families = new Set(records.filter(record => record.kind === "family").map(record => record.id));
  for (const record of records.filter(record => record.kind === "breakthrough")) {
    if (!record.breakthrough) { errors.push(`${record.id}: missing mandatory core`); continue; }
    const coreFamilies = [...new Set(expressionReferences(record.breakthrough.core).map(path => path.replace(/^g\./, "").split(".")[0]!).filter(id => families.has(id)))];
    if (coreFamilies.length === 0) { errors.push(`${record.id}: mandatory core names no family`); continue; }
    for (const coreFamily of coreFamilies) {
      const engine = new GameEngine(records);
      for (const candidate of records) Object.assign(engine.stat(candidate.id), { value: 100, max: 100, exp: 0, reps: 100, open: true, started: true });
      Object.assign(engine.stat(record.id), { value: 0, reps: 0, max: 1, started: false });
      engine.stat(coreFamily).value = 0;
      engine.state.disabledIds = [];
      engine.state.visibleIds = records.map(candidate => candidate.id);
      if (engine.availability(record.id).ok) errors.push(`${record.id}: mandatory core is skippable with ${coreFamily} at zero`);
    }
  }
  return errors;
}

export function validateContent(records: GameRecord[] = sourceRecords): ValidationReport {
  const errors = validateGrammar(records);
  if (errors.length) return { ok: false, errors, routes: [], coverageBranches: [], recordCount: records.length, reachedCount: 0, missing: records.map(record => record.id) };
  errors.push(...validateMandatoryCores(records));
  const routes = (Object.keys(ROUTES) as OpeningRoute[]).map(name => runRoute(name, { records }));
  for (const route of routes) {
    if (!route.success) errors.push(`${route.name}: Foundation unreachable (${route.reason})`);
    else if (route.foundationSeconds! > 2700) errors.push(`${route.name}: Foundation takes ${(route.foundationSeconds! / 60).toFixed(2)} min, over 45 min`);
    if (route.state.bank.spentSinceCheckpoint > 0 || route.state.bank.seconds > 0) errors.push(`${route.name}: route used or accrued bank; pacing requires only ordinary activity`);
  }
  const coverageBranches = runCoverageBranches(records);
  const reached = new Set([...routes, ...coverageBranches].flatMap(route => route.reached));
  const missing = records.filter(record => !reached.has(record.id)).map(record => record.id);
  if (missing.length) errors.push(`No cold-start reachability witness for: ${missing.join(", ")}`);
  // Replayable witnesses must actually satisfy each lead's need; mere early visibility is insufficient.
  for (const route of coverageBranches) if (!route.success) errors.push(`${route.name}: coverage branch failed (${route.reason})`);
  return { ok: errors.length === 0, errors, routes, coverageBranches, recordCount: records.length, reachedCount: reached.size, missing };
}

if (import.meta.main) {
  const report = validateContent();
  if (process.argv.includes("--json")) console.log(JSON.stringify({ ...report, routes: report.routes.map(compactRoute), coverageBranches: report.coverageBranches.map(compactRoute) }, null, 2));
  else {
    for (const route of [...report.routes, ...report.coverageBranches]) console.log(`${route.name}: ${route.success ? "Foundation" : "BLOCKED"} at ${((route.foundationSeconds ?? route.activitySeconds) / 60).toFixed(2)} min; ${route.reached.length} records witnessed; ${route.unknownRaiserLog.length} unknown-raiser cap lines`);
    console.log(`Reachability: ${report.reachedCount}/${report.recordCount} records across distinct cold-start branches.`);
    for (const error of report.errors) console.error(`FAIL ${error}`);
    console.log(report.ok ? "OK: actual JSON and engine validation passed" : "FAILED");
  }
  if (!report.ok) process.exitCode = 1;
}
