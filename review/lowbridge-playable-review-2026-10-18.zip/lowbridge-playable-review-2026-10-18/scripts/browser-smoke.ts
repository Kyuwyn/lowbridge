import { chromium, type Page } from 'playwright';
import { mkdir } from 'node:fs/promises';
import { join } from 'node:path';
import { startServer } from './serve';
import { runRoute, ROUTES, type OpeningRoute } from './routes';
import { records, recordById } from '../src/content';
import { GameEngine } from '../src/engine';
import { decodeSave, makeSave, DATABASE_NAME, type SaveFile } from '../src/persistence';

const output = join(import.meta.dir, '../playtest');
await mkdir(output, { recursive: true });
const server = await startServer(0);
const browser = await chromium.launch({ headless: true });
const errors: string[] = [];
const reports: Record<string, unknown>[] = [];

async function stored(page: Page): Promise<SaveFile> {
  return page.evaluate(async name => new Promise((resolve, reject) => {
    const open = indexedDB.open(name, 1);
    open.onerror = () => reject(open.error);
    open.onsuccess = () => {
      const db = open.result;
      const transaction = db.transaction('saves', 'readonly');
      const request = transaction.objectStore('saves').get('current');
      transaction.oncomplete = () => { db.close(); resolve(request.result); };
      transaction.onabort = () => { db.close(); reject(transaction.error); };
    };
  }), DATABASE_NAME) as Promise<SaveFile>;
}

function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

async function importSave(page: Page, save: unknown) {
  await page.locator('.settings > summary').click();
  await page.locator('[data-ui=file]').setInputFiles({ name: 'smoke-save.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(save)) });
  await page.waitForFunction(() => !document.querySelector<HTMLButtonElement>('[data-ui=export]')?.disabled);
}

try {
  for (const name of Object.keys(ROUTES) as OpeningRoute[]) {
    const expected = runRoute(name);
    assert(expected.success, `${name}: simulation did not reach Foundation`);
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage();
    page.on('pageerror', error => errors.push(`${name}: ${error.message}`));
    const started = performance.now();
    await page.clock.install({ time: new Date('2026-10-18T23:00:00Z') });
    await page.clock.pauseAt(new Date('2026-10-18T23:00:01Z'));
    await page.goto(server.url.toString());
    await page.getByRole('heading', { name: 'Lowbridge', exact: true }).waitFor();
    await page.locator('[data-record-id=mill_work] [data-action=start]').waitFor();
    if (name === 'channel-only') await page.screenshot({ path: join(output, 'opening-desktop.png'), fullPage: true });
    for (const action of expected.actions) {
      const record = recordById.get(action.id)!;
      if (record.kind !== 'breakthrough') {
        const group = record.group === 'Practice' || record.group === 'Sites' || record.group === 'Home' ? record.group : 'Work';
        await page.locator(`button[aria-controls=group-${group.toLowerCase()}]`).click();
      }
      const card = page.locator(`[data-record-id="${action.id}"]`);
      const select = card.locator('select');
      if (await select.count() && await select.isVisible()) {
        if (action.objective.kind === 'resource') {
          await select.selectOption(`resource:${action.objective.id}`);
          await card.locator('input').fill(String(action.objective.target));
        } else await select.selectOption('');
      }
      await card.locator('[data-action=start]').click();
      if (action.elapsed) await page.clock.runFor(action.elapsed * 1000);
    }
    await page.locator('[data-ui=completion]').waitFor({ state: 'visible' }).catch(() => {});
    const save = decodeSave(await stored(page), records);
    assert(save.state.stats.foundation.value === 1, `${name}: browser did not reach Foundation`);
    assert(save.state.activitySeconds === expected.activitySeconds, `${name}: browser/simulation time mismatch ${save.state.activitySeconds} vs ${expected.activitySeconds}`);
    for (const family of ['lore', 'qi_sense', 'circulation']) assert(save.state.stats[family].value === expected.state.stats[family].value, `${name}: ${family} differs`);
    assert(save.state.active === null, `${name}: did not pause at Foundation`);
    assert(save.state.lifespan === 85 && save.state.bank.cap === 21600, `${name}: Foundation rewards missing`);
    await Bun.write(join(output, `${name}-foundation.json`), JSON.stringify(save, null, 2));
    await page.screenshot({ path: join(output, `${name}-foundation.png`), fullPage: true });
    await page.reload();
    await page.locator('[data-ui=export]').waitFor({ state: 'attached' });
    const restored = decodeSave(await stored(page), records);
    assert(restored.state.stats.foundation.value === 1, `${name}: reload lost Foundation`);
    assert(restored.state.activitySeconds === expected.activitySeconds, `${name}: reload duplicated activity`);
    for (const width of [768, 390]) {
      await page.setViewportSize({ width, height: 900 });
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
      assert(!overflow, `${name}: horizontal overflow at ${width}px`);
      if (width === 390 && name === 'channel-only') await page.screenshot({ path: join(output, 'foundation-mobile.png'), fullPage: true });
    }
    reports.push({ name, browserWallSeconds: (performance.now() - started) / 1000, activitySeconds: save.state.activitySeconds,
      actionCount: expected.actions.length, levels: expected.levels, unlocks: expected.unlocks, unknownRaiserLog: expected.unknownRaiserLog,
      reload: 'pass', responsiveWidths: [1440, 768, 390] });
    await context.close();
    console.log(`Browser ${name}: Foundation in ${save.state.activitySeconds}s ordinary activity; real UI clicks/reload/layout PASS`);
  }

  // An independent fresh context exercises the pause-and-bank lifecycle and real IndexedDB.
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  let page = await context.newPage();
  page.on('pageerror', error => errors.push(`persistence: ${error.message}`));
  await page.clock.install({ time: new Date('2026-10-18T23:00:00Z') });
  await page.clock.pauseAt(new Date('2026-10-18T23:00:01Z'));
  await page.goto(server.url.toString());
  await page.locator('[data-record-id=mill_work] [data-action=start]').click();
  await page.clock.runFor(10_000);
  const partial = decodeSave(await stored(page), records);
  assert(partial.state.active?.progress === 10 && partial.state.bank.seconds === 0, 'active wall time was banked or not saved');
  await page.close();
  page = await context.newPage();
  page.on('pageerror', error => errors.push(`offline return: ${error.message}`));
  await page.clock.install({ time: new Date('2026-10-18T23:01:40Z') });
  await page.clock.pauseAt(new Date('2026-10-18T23:01:41Z'));
  await page.goto(server.url.toString());
  await page.locator('[data-record-id=mill_work] [data-action=start]').waitFor();
  const resumed = decodeSave(await stored(page), records);
  assert(resumed.state.stats.coin.value === 3 && resumed.state.activitySeconds === 30 && resumed.state.bank.seconds === 70, 'return visit failed objective stop/unused time accounting');

  const targetSelect = page.locator('[data-objective=mill_work]');
  await targetSelect.selectOption('resource:coin');
  const target = page.locator('[data-target=mill_work]');
  await target.fill('20'); await target.focus(); await page.clock.runFor(1000);
  assert(await target.evaluate(node => node === document.activeElement && (node as HTMLInputElement).value === '20'), 'tick replaced focused objective control');
  await page.locator('[data-record-id=mill_work] [data-action=start]').click();
  await page.locator('[data-action=accelerate]').click();
  const spent = decodeSave(await stored(page), records);
  assert(spent.state.bank.seconds === 0 && spent.state.active !== null && spent.state.activitySeconds === 101, 'bank depletion did not leave current objective running');

  const second = await context.newPage();
  await second.goto(server.url.toString());
  await second.getByRole('heading', { name: 'Lowbridge is open in another tab' }).waitFor();
  await second.close();

  // Import rejects corruption, then valid import replaces exactly and ignores old export time.
  await importSave(page, { format: 'not-lowbridge', version: 1 });
  await page.locator('[data-ui=settings-feedback]').waitFor({ state: 'visible' });
  assert((await stored(page)).state.activitySeconds === spent.state.activitySeconds, 'bad import changed the saved game');
  const fresh = makeSave(new GameEngine(records).state, 1);
  await page.locator('[data-ui=file]').setInputFiles({ name: 'fresh.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(fresh)) });
  await page.waitForFunction(() => !document.querySelector<HTMLButtonElement>('[data-ui=export]')?.disabled);
  const imported = decodeSave(await stored(page), records);
  assert(imported.state.activitySeconds === 0 && imported.state.bank.seconds === 0, 'import added offline credit to a snapshot');
  const downloadEvent = page.waitForEvent('download');
  await page.locator('[data-ui=export]').click();
  const exported = await downloadEvent;
  await exported.saveAs(join(output, 'fresh-start.json'));
  decodeSave(await Bun.file(join(output, 'fresh-start.json')).text(), records);
  await page.clock.setSystemTime(new Date('2026-10-17T23:00:00Z'));
  await page.locator('[data-record-id=mill_work] [data-action=start]').click();
  await page.clock.runFor(10_000);
  const backwards = decodeSave(await stored(page), records);
  assert(backwards.state.activitySeconds === 10 && backwards.state.bank.seconds === 0, 'clock rollback froze activity or autosaving');
  await page.clock.setSystemTime(new Date('2026-10-18T23:00:00Z'));
  await page.clock.runFor(20_000);
  const forwards = decodeSave(await stored(page), records);
  assert(forwards.state.activitySeconds === 30 && forwards.state.bank.seconds === 0, 'clock correction counted elapsed time twice');
  reports.push({ name: 'persistence-and-controls', returnVisit: 'pass', bankDepletion: 'pass', objectiveFocus: 'pass', secondTab: 'pass', importExport: 'pass', clockCorrection: 'pass' });
  await context.close();
  assert(errors.length === 0, `Browser errors: ${errors.join('; ')}`);
  await Bun.write(join(output, 'smoke-results.json'), JSON.stringify({ browser: await browser.version(), reports, errors }, null, 2));
  console.log('Browser persistence, bank, focus, second-tab and import/export PASS');
} finally {
  await browser.close();
  server.stop(true);
}
